<?php
session_start();
require_once ('../../includes/library/functions.php');
require_once('../../includes/db-config.php');
require_once ('../../layouts/header.php');
?>