<?php
session_start();
require_once '../../includes/db-config.php';
require_once '../../includes/library/functions.php';
$title = isset($page_title) ? $page_title : '';

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>AMS<?php echo(!empty($title) ? "::{$title}" : '') ?></title>
    <link rel="stylesheet" href="../css/student.css">
</head>
<body>
<header id="m-site">
    <nav>
        <div id="site-logo">
            <img src="../assets/images/logo-png.png" alt="">
        </div>
        <i class="fa fa-bars" id="toggle"></i>
        <div id="menu" data-state="close" class="slideOut">
            <i class="fa fa-close" id="close"></i>

            <ul>
                <?php if(!validate_student_logged_in()): ?>
                <li><a href="http://localhost/ams/public/">Home</a></li>
                <li><a href="./index.php">About</a></li>
                <?php endif; ?>
            </ul>

      <?php if(validate_student_logged_in()) { ?>
<!--            Mobile Menu Only -->
          <nav id="std-menu">
              <ul>
                  <li><a href="./dashboard.php">Dashboard</a></li>
                  <li><a href="./profile.php">Profile</a></li>
                  <li><a href="./manage-course.php">Manage Course Registration</a></li>
              </ul>
          </nav>
      <?php } ?>
            <ul>

                <?php if(!validate_student_logged_in()) { ?>

                <li><a href="./login.php" class="btn">Sign In</a></li>
                <li><a href="./register.php" class="btn">Sign Up</a></li>
                <?php } else { ?>
                    <li id="logout"><a class="btn" href="./logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a></li>
                    <i class="fa fa-bars" id="side-toggle" data-state="close"></i>
                <?php } ?>
            </ul>

        </div>
    </nav>
</header>