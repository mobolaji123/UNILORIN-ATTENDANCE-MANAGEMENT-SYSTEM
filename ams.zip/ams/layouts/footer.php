<script>
    const menuToggle = document.querySelector('#menu-toggle'),
        sideBar = document.querySelector('.sidebar')
    menuToggle.addEventListener('click', (e) => {
        let curState = e.target.getAttribute('data-state')
        switch (curState) {
            case 'close':
                e.target.classList.replace('fa-bars','fa-close')
               e.target.setAttribute('data-state', 'open')
                break;
            case 'open':
                e.target.classList.replace('fa-close','fa-bars')
                e.target.setAttribute('data-state', 'close')
                break
        }
        sideBar.classList.toggle('slideLeft')
    })

</script>
<footer>
    <p>&copy; Copyright 2025 <b>Attendance Management System</b> &reg;</p>
    <p>Powered by <b>Fareed</b></p>
</footer>
</body>
</html>