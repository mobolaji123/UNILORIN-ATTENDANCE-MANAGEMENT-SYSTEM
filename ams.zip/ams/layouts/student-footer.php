<footer>
    <p>&copy; Copyright 2025 <b>Attendance Management System</b> &reg;</p>
    <p>Powered by <b>Fareed</b></p>
</footer>
<script src="../scripts/jquery-3.7.1.min.js"></script>
<script src="../scripts/owl.carousel.min.js"></script>
<script>
    $(document).ready(function () {
        $('.owl-carousel').owlCarousel({
            autoplay: true,
            items: 1,
            loop: true,
            autoplayTimeout: 5000,
            nav: true,
            navText: ['&larr;', '&rarr;']
        })
    })
    const menu = document.querySelector('#menu'),
        toggleBtn = document.querySelector('#toggle'),
        closeBtn = document.querySelector('#close'),
        sideBar = document.querySelector('#sidebar')
        sideBarBtn = document.querySelector('#side-toggle')
    toggleBtn.addEventListener('click', () => {
        if(menu.getAttribute('data-state') === 'close') {
            if(menu.classList.contains('slideOut')) {
                menu.classList.replace('slideOut', 'slideIn')
                menu.setAttribute('data-state', 'open')
            }
        }
    });
    closeBtn.addEventListener('click', () => {
        if(menu.getAttribute('data-state') === 'open') {
            if(menu.classList.contains('slideIn')) {
                menu.classList.replace('slideIn', 'slideOut')
                menu.setAttribute('data-state', 'close')
            }
        }
    });
    sideBarBtn.addEventListener('click', (e) => {
        let state = e.target.getAttribute('data-state')
        switch (state) {
            case 'close':
                e.target.setAttribute('data-state', 'open')
                e.target.classList.replace('fa-bars', 'fa-close')
                break;
            case 'open':
                e.target.setAttribute('data-state', 'close')
                e.target.classList.replace('fa-close', 'fa-bars')
            break;
        }
        sideBar.classList.toggle('slideLeft')

    })
</script>
</body>
</html>