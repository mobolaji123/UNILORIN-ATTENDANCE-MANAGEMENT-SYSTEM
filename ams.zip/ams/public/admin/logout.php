<?php
require_once '../../layouts/admin-partial-header.php';

if(isset($_SESSION['admin'])){
    unset($_SESSION['admin']);
    session_destroy();
    redirectTo('./login.php');
}

