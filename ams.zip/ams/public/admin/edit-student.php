<?php
$page_title = 'View Student';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $staff = get_table_record_by_col('staffs', [ 'id' => (int)$_SESSION['admin']['sid']]);
    $student = get_table_record_by_col('students', [ 'id' => (int)$_GET['sid']]);
    $departments = get_table_record_by_col('departments');
    if(isset($_POST['update'])) {
        $errors = [];
        $rules = [
                'matric_no' => [
                        'required' => true,
                        'display' => 'Matric No'
                ],
                'surname' => [
                        'required' => true,
                    'min' => 3,
                    'max' => 20,
                    'display' => 'Surname'
                ],
            'firstname' => [
                'required' => true,
                'min' => 3,
                'max' => 20,
                'display' => 'firstname'
            ],
            'othername' => [
                'required' => true,
                'min' => 3,
                'max' => 20,
                'display' => 'Othername'
            ],
            'gender' => [
                    'required' => true,
                    'display' => 'Gender'
            ],
            'department' => [
                    'required' => true,
                'display' => 'Department'
            ]
        ];
        setDefault(['gender', 'department']);
        $errors = array_merge($errors, validateInput($rules, 'post'));
        if(empty($errors)) {
            if(update_db_table('students', [
                    'matric_no' => $_POST['matric_no'],
                    'surname' => clean_string($_POST['surname']),
                    'firstname' => clean_string($_POST['firstname']),
                    'othername' => !empty($_POST['othername']) ? clean_string($_POST['othername']) : NULL,
                    'gender' => $_POST['gender'],
                    'department' => $_POST['department']
            ], ['id' => (int)$_POST['sid']])) {
                set_flash_message('success','info', 'Successfully Updated student details.');
                header('Location: manage-student.php');
            }
        }
    }
}
?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Edit Student Bio-Data</h1>
        <nav class="sub-menu">
            <a href="<?php echo($_SERVER['HTTP_REFERER']) ?>">&larr; Back</a>
        </nav>
        <form action="" method="post">
            <div class="form-group">
                <label for="matric">Matric No</label>
                <input class="form-control" type="text" name="matric_no" id="matric" value="<?php echo($student->matric_no) ?>">
            </div>
            <div class="form-group">
                <label for="surname">Surname</label>
                <input class="form-control" type="text" name="surname" id="surname" pattern="[a-zA-Z]{3,20}" value="<?php echo($student->surname) ?>">
            </div>
            <div class="form-group">
                <label for="firstname">Firstname</label>
                <input class="form-control" type="text" name="firstname" id="firstname" pattern="[a-zA-Z]{3,20}" value="<?php echo($student->firstname) ?>">
            </div>
            <div class="form-group">
                <label for="othername">Othername</label>
                <input class="form-control" type="text" name="othername" id="othername" pattern="[a-zA-Z]{3,20}" value="<?php echo($student->othername) ?>">
            </div>
            <div class="form-group">
                <label for="gender">Gender</label>
                <select name="gender" id="gender" class="form-control">
                    <option value="male" <?php echo($student->gender === 'male' ? 'selected' : '') ?>>Male</option>
                    <option value="female" <?php echo($student->gender === 'female' ? 'selected' : '') ?>>Female</option>
                </select>
            </div>
            <div class="form-group">
                <label for="dept">Department</label>
                <select name="department" id="dept" class="form-control">
                    <?php foreach ($departments as $pos => $department): ?>
                        <option <?php echo($student->department === $department->id ? 'selected' : '') ?> value="<?php echo($department->id) ?>"><?php echo(ucwords($department->department)) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="submit-btn" name="update">Update Info</button>
        </form>
    </main>
</div>

<?php require_once('../../layouts/footer.php') ?>