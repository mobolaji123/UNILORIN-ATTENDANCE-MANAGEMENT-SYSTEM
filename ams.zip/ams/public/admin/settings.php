<?php
$page_title = 'Exam Attendance Registrations';
require_once '../../layouts/admin-partial-header.php';

if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {

    $active_staff = get_table_record_by_col('staffs', ['id' => (int)$_SESSION['admin']['sid']]);
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $total = get_table_records_count('attendance_settings');
    $perPage = 10;
    $totalPages = ceil($total / $perPage);
    $offset = ($page - 1) * $perPage;
    $sql = "SELECT * FROM `attendance_settings` ORDER BY id DESC LIMIT :offset, :perPage";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindParam(':perPage', $perPage, PDO::PARAM_INT);
    $stmt->execute();
    $settings = $stmt->fetchAll(PDO::FETCH_OBJ);
}

?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Setting Exam Attendance Registration History</h1>
        <nav class="sub-menu">
            <?php if(!empty($settings)) { ?>
            <form action="">
                <select name="" id="" class="form-control">
                    <option selected disabled>-- choose Status --</option>
                    <option value="open">Open</option>
                    <option value="closed">Closed</option>
                </select>
                <button type="submit" class="btn">Clear Filter</button>
            </form>
            <?php } ?>
            <a href="./new-exam-setting.php" class="btn">Set New Exam Registration</a>
        </nav>
        <p><?php echo(get_flash_message('info')) ?></p>
    <?php if(empty($settings)) { ?>
        <p>No Settings Record Found !</p>
   <?php } else { ?>
        <div class="responsive">
        <table>
            <thead>
                <tr>
                    <th>S/N</th>
                    <th>Session</th>
                    <th>Start Date</th>
                    <th>Closing Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $sn = 1;
            foreach ($settings as $ind => $setting): ?>
            <tr>
                <td><?php echo($sn++) ?></td>
                <td><?php echo($setting->session) ?></td>
                <td><?php echo($setting->open_at) ?></td>
                <td><?php echo($setting->close_at) ?></td>
                <td>
                    <form action="#">
                        <select name="status" class="status form-control" data-target="<?php echo($setting->id) ?>">
                            <option value="open" <?php echo($setting->status === 'open' ? 'selected' : '') ?>>Open</option>
                            <option value="closed" <?php echo($setting->status === 'closed' ? 'selected' : '') ?>>Closed</option>
                        </select>
                    </form>
                </td>
                <td><a href="settings-destroy.php?setID=<?php echo($setting->id) ?>&action=delete">Delete</a></td>
            </tr>
        <?php endforeach; ?>
            </tbody>
        </table>
        </div>
<!--        Pagination Section -->
        <ul class="pagination">
            <?php if($page > 1): ?>
                <li><a href="?page=<?php echo($page + 1) ?>">&larr; Prev</a></li>
            <?php endif; ?>
            <?php for($i = 1; $i <= $totalPages; $i++): ?>
                <?php if($i == $page) { ?>
                    <li class="active"><a href="?page=<?php echo($i) ?>"><?php echo($i) ?></a></li>
                <?php } else { ?>
                    <li><a href="?page=<?php echo($i) ?>"><?php echo($i) ?></a></li>
                <?php } ?>
            <?php endfor; ?>
            <?php if($page < $totalPages): ?>
                <li><a href="?page=<?php echo($page + 1) ?>"> Next &rarr;</a></li>
            <?php endif; ?>
        </ul>
        <!--            End of Pagination -->
    <?php } ?>
    </main>


</div>
<?php require_once('../../layouts/footer.php') ?>
<script>
    const statusAll = document.querySelectorAll('.status')
    if(statusAll.length) {
        statusAll.forEach(select => {
            select.addEventListener('change', (e) => {
             let selected = e.target.options[e.target.selectedIndex],
             id = e.target.getAttribute('data-target');
             selected.setAttribute('selected', true)
                let xhr = new XMLHttpRequest()

                xhr.open('GET', `../../supports/status-settings.php?id=${id}&status=${selected.value}`)
                xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest')
                xhr.onreadystatechange = () => {
                    if(xhr.readyState == 4 && xhr.status == 200) {
                        let responseText = xhr.responseText
                        let json = JSON.parse(responseText);
                        if(json.status == 'done') {
                            selected.setAttribute('selected', true);
                        }
                        console.log(json)

                    }
                }
                xhr.send()

            })
        })
    }
</script>
