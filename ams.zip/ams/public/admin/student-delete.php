<?php
$page_title = 'Manage Students';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    if (isset($_GET['action']) && $_GET['action'] == 'delete') {
        $student_id = (int)$_GET['stdID'];
//        echo($student_id) . ' will be deleted';
        $student = get_table_record_by_col('students', ['id' => $student_id]);
        if (!empty($student->profile_image)) {
            file_delete($student->profile_image);
        }
        delete_table_record('students', ['id' => $student->id]);
        set_flash_message('error', 'info', 'The student has been deleted.');
        header('location', 'manage-students.php');
    }
}
?>
<script>
    window.location.href = './manage.php?ref=staff'
</script>
