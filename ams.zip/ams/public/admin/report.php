<?php
$page_title = 'Report';
require_once '../../layouts/admin-partial-header.php';

if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
  $active_staff = get_table_record_by_col('staffs', ['id' => (int)$_SESSION['admin']['sid']]);
  $course_registrations = get_table_record_by_col('course_registrations');
    $departments = get_table_record_by_col('departments');
}

?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Exam Attendance &amp; Registration Report</h1>
        <div class="dept-grid">
            <?php foreach ($departments as $pos => $department): ?>
            <a href="manage.php?ref=staff">
                <h4><?php echo(ucwords($department->department)) ?></h4>
                <span><?php echo(get_table_records_count('course_registrations', ['department_id' => $department->id])) ?></span>
                <p>total</p>
            </a>
            <?php endforeach; ?>
        </div>
    </main>

</div>
<?php require_once('../../layouts/footer.php') ?>