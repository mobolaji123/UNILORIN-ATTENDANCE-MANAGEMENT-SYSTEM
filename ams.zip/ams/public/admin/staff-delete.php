<?php
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
}
if(isset($_GET['staff'])) {
        $staff_id = (int)$_GET['staff'];
        $staff = get_table_record_by_col('staffs', ['id' => $staff_id]);
        delete_table_record('staffs', ['id' => $staff_id]);
        set_flash_message('error', 'info', 'Staff Account has been Successfully deleted.');
}
header('location', './manage.php?ref=staff');
?>
<script>
    window.location.href = './manage.php?ref=staff'
</script>
