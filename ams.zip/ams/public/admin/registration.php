<?php
$page_title = 'Course Registration';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $active_staff = get_table_record_by_col('staffs', ['id' => (int)$_SESSION['admin']['sid']]);
    try {
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $perPage = 10;
        $c_sql = "SELECT COUNT(*) AS 'total' FROM `course_registrations` GROUP BY `student_id`";
        $c_stmt = $db->prepare($c_sql);
        $c_stmt->execute();
        $total_count = $c_stmt->rowCount();
        $total_pages = ceil($total_count / $perPage);
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT `student_id` FROM `course_registrations` GROUP BY `student_id` LIMIT :limit OFFSET :offset";
        $stmt = $db->prepare($sql);

        $stmt->bindParam(':limit', $perPage, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $registrations = $stmt->fetchAll(PDO::FETCH_OBJ);
    } catch(PDOException $e) {
    }
}
?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Registration History</h1>
        <header>
            <nav>

            </nav>
        </header>
        <?php if(!empty($registrations)) { ?>
        <div class="responsive">
        <table>
            <thead>
                <tr>
                    <th>S/N</th>
                    <th>Student Fullname</th>
                    <th>Department</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sn = 1;
                foreach ($registrations as $pos => $registration) : ?>
            <tr>
                <td><?php echo($sn) ?></td>
                <td><?php echo(ucwords(getFullname($registration->student_id))) ?></td>
                <td>
                    <?php
                    $department = get_table_record_by_col('departments', ['id' => get_table_record_by_col('students', ['id' => $registration->student_id])->department]);
                    echo($department->department);
                    ?>

                </td>
                <td>
                    <a href="registration-detail.php?sid=<?php echo($registration->student_id) ?>">View History</a>
                </td>
            </tr>
                <?php
                $sn++;
                endforeach; ?>
            </tbody>
        </table>
        </div>
<!-- Start of Pagination -->
            <ul class="pagination">
                <?php if($page > 1): ?>
                    <li><a href="?page=<?php echo($page + 1) ?>">&larr; Prev</a></li>
                <?php endif; ?>
                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                    <?php if($i == $page) { ?>
                        <li class="active"><a href="?page=<?php echo($i) ?>"><?php echo($i) ?></a></li>
                    <?php } else { ?>
                        <li><a href="?page=<?php echo($i) ?>"><?php echo($i) ?></a></li>
                    <?php } ?>
                <?php endfor; ?>
                <?php if($page < $total_pages): ?>
                    <li><a href="?page=<?php echo($page + 1) ?>"> Next &rarr;</a></li>
                <?php endif; ?>
            </ul>
<!-- End of Pagination -->
        <?php } else { ?>
        <p>No registrations yet... !</p>
        <?php } ?>
    </main>
</div>
<?php require_once('../../layouts/footer.php') ?>