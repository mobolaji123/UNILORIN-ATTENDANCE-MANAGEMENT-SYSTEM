<?php
$page_title = 'Registration History';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $active_staff = get_table_record_by_col('staffs', ['id' => (int)$_SESSION['admin']['sid']]);
    $historys_count = get_table_records_count('course_registrations', ['student_id' => (int)$_GET['sid']]);
    $historys = [];
    if($historys_count > 1) {
        $historys = get_table_record_by_col('course_registrations', ['student_id' => (int)$_GET['sid']]);
    } else if($historys_count == 1) {
        $historys[0] = get_table_record_by_col('course_registrations', ['student_id' => $_GET['sid']]);
    }

}
?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Registration History</h1>
        <header>
            <nav class="sub-menu">
                <a href="<?php echo($_SERVER['HTTP_REFERER']) ?>">&larr; Back</a>
            </nav>
        </header>
        <div class="responsive">
        <table>
            <thead>
                <tr>
                    <th>S/N</th>
                    <th>Student Fullname</th>
                    <th>Department</th>
                    <th>Level</th>
                    <th>Approval</th>
                    <th colspan="2">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sn = 1;
                foreach ($historys as $pos => $history): ?>
                <tr>
                    <td><?php echo($sn) ?></td>
                    <td><?php echo(ucwords(getFullname($history->student_id))) ?></td>
                    <td>
                        <?php
                        $department = get_table_record_by_col('departments', ['id' => get_table_record_by_col('students', ['id' => $history->student_id])->department]);
                        echo($department->department);
                        ?>
                    </td>
                    <td><?php echo($history->level) ?>L</td>
                    <td>
                        <form action="update-course-reg-stat.php" method="get" class="statFrm">
                            <?php $status = $history->status ?>
                            <select name="status" id="">
                                <option <?php echo($status === 'approved' ? 'selected' : '') ?> value="approved" data-student="<?php echo($history->student_id) ?>" data-level="<?php echo($history->level) ?>">Approved</option>
                                <option <?php echo($status === 'pending' ? 'selected' : '') ?> value="pending" data-student="<?php echo($history->student_id) ?>" data-level="<?php echo($history->level) ?>">Pending</option>
                            </select>
                        </form>
                    </td>
                    <td><a href="./course-detail.file.php?sid=<?php echo(base64_encode('Secret#' . $history->student_id)) ?>&level=<?php echo(base64_encode('Secure#'. $history->level)) ?>">view detail</a></td>
                    <td><a href="update-course-reg-stat.php?sid=<?php echo($history->student_id) ?>&level=<?php echo($history->level) ?>&action=delete">Delete</a></td>
                </tr>
                <?php
                $sn++;
                endforeach; ?>
            </tbody>
        </table>
        </div>
    </main>
</div>
<?php require_once('../../layouts/footer.php') ?>
<script>
    const allStatus = document.querySelectorAll('select[name="status"]')
    for(let status of allStatus) {
        status.addEventListener('change', (e) => {
            let curStat = e.target.options[e.target.selectedIndex].value,
                studentId = e.target.options[e.target.selectedIndex].getAttribute('data-student'),
                level = e.target.options[e.target.selectedIndex].getAttribute('data-level')
            let targetUrl = e.target.parentElement.getAttribute('action')
            let url = `${targetUrl}?sid=${studentId}&level=${level}&status=${curStat}&action=update`
            window.location.href = url
        })
    }
</script>
