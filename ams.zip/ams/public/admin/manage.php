<?php
$ref = $_GET["ref"];
$page_title = 'Manage';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $active_staff = get_table_record_by_col('staffs', ['id' => (int)$_SESSION['admin']['sid']]);
    $departments_count = get_table_records_count('departments');
    $students_count = get_table_records_count('students');
    $staff_count = get_table_records_count('staffs');
}
?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <?php
        if ($ref === 'staff')  {
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $staff_count = get_table_records_count('staffs');
            $per_page = 10;
            $offset = ($page - 1) * $per_page;
            $total_pages = ceil($staff_count / $per_page);
            $sql = "SELECT * FROM staffs LIMIT :offset, :per_page";
            $stmt = $db->prepare($sql);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->bindParam(':per_page', $per_page, PDO::PARAM_INT);
            if($stmt->execute()) {
                $staffs = $stmt->fetchAll(PDO::FETCH_OBJ);
            }
            ?>
        <h1><?php echo('Manage '. $ref)  ?></h1>
        <p><?php echo(get_flash_message('info')) ?></p>
        <nav class="sub-menu">
            <a href="./create.php?type=new" class="btn">Create New</a>
        </nav>
        <div class="responsive">
       <table>
           <thead>
           <tr>
               <th>SN</th>
               <th>Fullname</th>
               <th>Phone Number</th>
               <th>Employee Type</th>
               <th colspan="2">Action</th>
           </tr>
           </thead>
           <tbody>
                <?php foreach ($staffs as $pos => $staff): ?>
               <tr>
                   <td><?php echo($pos + 1) ?></td>
                   <td><?php echo(ucwords($staff->fullname)) ?></td>
                   <td><?php echo($staff->phone) ?></td>
                   <td><?php echo($staff->employeeType) ?></td>
                   <td><a href="./create.php?type=edit&sid=<?php  echo($staff->id); ?>">Edit</a></td>
                   <?php if($active_staff->id !== $staff->id): ?>
                       <td><a href="#" data-staff="<?php echo($staff->id) ?>" class="delBtn">Delete</a></td>
                   <?php endif; ?>
               </tr>
               <?php endforeach; ?>
           </tbody>
       </table>
        </div>
            <!--            Pagination Section-->
            <ul class="pagination">
                <?php if($page > 1): ?>
                    <li><a href="?ref=staff&page=<?php echo($page + 1) ?>">&larr; Prev</a></li>
                <?php endif; ?>
                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                    <?php if($i == $page) { ?>
                        <li class="active"><a href="?ref=staff&page=<?php echo($i) ?>"><?php echo($i) ?></a></li>
                    <?php } else { ?>
                        <li><a href="?ref=staff&page=<?php echo($i) ?>"><?php echo($i) ?></a></li>
                    <?php } ?>
                <?php endfor; ?>
                <?php if($page < $total_pages): ?>
                    <li><a href="?ref=staff&page=<?php echo($page + 1) ?>"> Next &rarr;</a></li>
                <?php endif; ?>
            </ul>
<!--            End of Staff Pagination -->

        <?php
        } elseif($ref === 'department') {
            $departments = get_table_records('departments');
            ?>

            <h1><?php echo('Manage '. $ref)  ?></h1>
            <p><?php echo(get_flash_message('info')) ?></p>
        <div class="responsive">
        <table>
            <thead>
                <tr>
                    <th>SN</th>
                    <th>Department</th>
                    <th>Code</th>
                    <th>No of Courses</th>
                    <th colspan="2">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sn = 1;
                foreach ($departments as $pos => $department): ?>
            <tr>
                <td><?php echo($sn++) ?></td>
                <td><?php echo($department->department) ?></td>
                <td><?php echo($department->code) ?></td>
                <td><?php echo(get_table_records_count('courses', ['department' => $department->id])) ?></td>
                <td><a href="manage-department.php?did=<?php echo($department->id) ?>">Edit</a></td>
                <td><a href="?ref=course&action=list&dept=<?php echo($department->id); ?>">View courses List</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php } elseif ($ref === 'course')  {
            $department_id = (int)$_GET['dept'];
            $department = get_table_record_by_col('departments', ['id' => $department_id]);
            ?>
            <nav class="sub-menu">
                <a href="<?php echo($_SERVER['HTTP_REFERER']) ?>" class="btn">&larr; Back</a>
            </nav>
            <h1><?php echo('View Courses List for ' . $department->department)  ?></h1>
            <?php

            $sql = 'SELECT DISTINCT `level` FROM courses WHERE `department` = :department';
            $stmt = $db->prepare($sql);
            $stmt->bindParam(':department', $department_id, PDO::PARAM_INT);
            $stmt->execute();
            if($stmt->rowCount()) {
                $levels = $stmt->fetchAll(PDO::FETCH_OBJ);

            }

            ?>
                <div class="responsive">
            <table>
                <thead>
                <tr>
                    <th>S/N</th>
                    <th>Title</th>
                    <th>Code</th>
                    <th>Units</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($levels as $pos => $level): ?>
                    <tr>
                        <th colspan="6"><?php echo($level->level . ' Level') ?></th>
                    </tr>
                    <?php $courses = get_table_record_by_col('courses', ['level' => $level->level, 'department' => $department_id]);
                    $sn = 1;
                    foreach ($courses as $ind => $course):

                        ?>
                    <tr>
                        <td><?php echo($sn) ?></td>
                        <td><?php echo($course->course_title) ?></td>
                        <td><?php echo($course->course_code) ?></td>
                        <td><?php echo($course->units) ?></td>
                        <td><?php echo($course->status) ?></td>
                    </tr>
                <?php
                    $sn++;
                    endforeach;
                endforeach;
                ?>

                </tbody>
            </table>
                </div>
        <?php } ?>
    </main>
</div>
<?php require_once('../../layouts/footer.php') ?>
<script>
    let delBtn = document.querySelectorAll('.delBtn')
    delBtn.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault()
            let staff = e.target.getAttribute('data-staff')
            let confirmation = prompt('Staff account will be Permanently Deleted ? Type "DELETE" for confirmation', '')
            if(confirmation === 'DELETE') {
                window.location.href = `./staff-delete.php?staff=${staff}`
            } else if( confirmation == null) {
                return
            } else {
                alert('Deletion Access Denied !')
            }
        })
    })
</script>