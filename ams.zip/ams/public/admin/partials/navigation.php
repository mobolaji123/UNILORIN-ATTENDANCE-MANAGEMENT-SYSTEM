<nav class="sidebar slideLeft">
    <ul>
        <li><a href="./index.php"><i class="fa fa-th"></i> Dashboard</a></li>
        <li><a href="./profile.php"><i class="fa fa-user"></i> Profile</a></li>
        <li><a href="./manage.php?ref=staff"><i class="fa fa-user"></i> Manage Staff</a></li>
        <li><a href="./manage-student.php"><i class="fa fa-user-graduate"></i> Manage Students</a></li>
        <li><a href="./registration.php"><i class="fa fa-book-atlas"></i> Course Registration</a></li>
        <li><a href="./report.php"><i class="fa fa-receipt"></i> Report</a></li>
        <li><a href="./manage.php?ref=department"><i class="fa fa-folder-plus"></i> Department &amp; Courses</a></li>
        <li><a href="./settings.php"><i class="fa fa-cogs"></i> Setting</a></li>
        <li><a href="./logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</nav>