<?php
$page_title = 'Update Department';
require_once '../../layouts/admin-partial-header.php';

if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {

    $active_staff = get_table_record_by_col('staffs', ['id' => (int)$_SESSION['admin']['sid']]);

    $errors = [];
    if(isset($_GET['did'])) {
        $department_id = $_GET['did'];
        $department = get_table_record_by_col('departments', ['id' => $department_id]);
    }
    if(isset($_POST['create'])) {
        $fields = [
               'department' => [
                       'required' => true,
                   'min' => 3,
                   'max' => 50,
                   'unique' => true,
                   'display' => 'Department'
               ] ,
                'code' => [
                        'required' => true,
                        'min' => 3,
                        'max' => 3,
                        'display' => 'Department Code'
                ]
        ];
        $errors = array_merge($errors, validateInput($fields, 'post', 'departments'));
        if(empty($errors)) {
            $id = (int)$_POST['did'];
            $department_name = clean_string($_POST['department']);
            $code = clean_string(strtoupper($_POST['code']));
            update_db_table('departments', ['department' => ucwords($department_name), 'code' => $code], ['id' => $id]);
            set_flash_message('success', 'info','Department updated successfully.');
            header('Location: manage.php?ref=department');
        }

    }
}
?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <nav class="sub-menu">
            <a href="<?php echo($_SERVER['HTTP_REFERER']) ?>" class="btn">&larr; Back</a>
        </nav>
        <h1>Edit Department Information</h1>

        <form method="POST" action="">
            <input type="hidden" value="<?php echo($department->id) ?>" name="did">
            <div class="form-group">
                <label for="name">Department <span class="error"><?php echo(show_error($errors, 'department')) ?></span></label>
                <input class="form-control" type="text" id="department" name="department" value="<?php echo( $department->department) ?>" />
            </div>
            <div class="form-group">
                <label for="code">Department Code <span class="error"><?php echo(show_error($errors, 'code')) ?></span></label>
                <input class="form-control" type="text" id="code" name="code" value="<?php echo( $department->code) ?>" >
            </div>
            <button type="submit" class="submit-btn" name="create">Update Department</button>

        </form>
    </main>

</div>
<?php require_once('../../layouts/footer.php') ?>