<?php
$page_title = 'Profile';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {

    $staff = get_table_record_by_col('staffs', [ 'id' => (int)$_SESSION['admin']['sid']]);

}
?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Profile</h1>
        <nav class="sub-menu">
            <a href="<?php echo($_SERVER['HTTP_REFERER']) ?>">&larr; Back</a>
            <a href="create.php?type=edit&sid=<?php echo($staff->id) ?>">Update Info</a>
            <a href="change-password.php?sid=<?php echo($staff->id) ?>">Change Password</a>

        </nav>
        <div class="responsive">
        <table>
            <tr>
                <td>Fullname</td>
                <td><?php echo(ucwords($staff->fullname)) ?></td>
            </tr>
            <tr>
                <td>E-mail</td>
                <td><?php echo($staff->email) ?></td>
            </tr>
            <tr>
                <td>Phone Number</td>
                <td><?php echo($staff->phone) ?></td>
            </tr>
            <tr>
                <td>Employee Type</td>
                <td><?php echo(ucwords($staff->employeeType)) ?></td>
            </tr>
        </table>
        </div>
    </main>
</div>
<?php require_once('../../layouts/footer.php') ?>
