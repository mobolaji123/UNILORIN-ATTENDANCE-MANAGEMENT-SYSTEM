<?php
$page_title = 'Admin Login';
require_once '../../layouts/admin-partial-header.php';
$errors = [];
if(validate_staff_logged_in()) {
    redirectTo('index.php');
}
if(isset($_POST['login'])){

    $fields = [
            'email' => [
                 'display' => 'E-mail Address',
                'required' => true,
            ],
            'password' => [
                'display' => 'Password',
                'required' => true,
            ]
    ];
    $errors = array_merge($errors, validateInput($fields, 'post'));
    if(empty($errors)){
        $email = $_POST['email'];
        $password = $_POST['password'];
        $staff = authenticate_staff($email, $password);
        if($staff){
            $_SESSION['admin']['sid'] = $staff->id;
            redirectTo('index');
        } else {
            $errors['login'] = 'Invalid login credentials';
        }

    }
}
?>

<div id="loginPage">
    <h1>Exam Attendance Management System</h1>
    <p>Welcome to the Staff Area</p>
   <?php if(!empty($errors['login'])): ?>
        <p class="error"><?php echo($errors['login']) ?></p>
    <?php endif; ?>
    <form action="<?php echo($_SERVER['PHP_SELF']) ?>" method="POST">
        <div class="form-group">
            <label for="email">E-mail <span class="error"><?php echo(show_error($errors, 'email')) ?></span></label>
            <input class="form-control" type="email" id="email" name="email" placeholder="Enter your E-mail address">
        </div>
        <div class="form-group">
            <label for="password">Password <span class="error"><?php echo(show_error($errors, 'password')) ?></span></label>
            <input class="form-control" type="password" id="password" name="password" placeholder="Enter the Password">
        </div>
        <p>
            <input type="checkbox" name="remember">
            <label for="">Remember Me</label>
        </p>
        <button type="submit" class="submit-btn" name="login">Sign In</button>

    </form>
    <p><a href="http://localhost/ams/public">Go to Homepage</a></p>
</div>

<?php require_once ('../../layouts/footer.php') ?>
