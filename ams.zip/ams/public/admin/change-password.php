<?php
$page_title = 'Change Password';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $errors = array();
    $sid = isset($_GET['sid']) ? (int)$_GET['sid'] : null;
    if(empty($sid)) {
        redirectTo('index.php');
    }
    if(isset($_POST['change'])) {
        $rules = array(
             'old_password' => array(
                 'required' => true,
                 'display' => 'Old Password',
             ),
            'password' => array(
                'required' => true,
                 'min' => 6,
                'display' => 'New Password',
            ),
            'confirm_password' => array(
                    'required' => true,
                    'match' => 'password',
                    'display' => 'Confirm Password'
            )
        );
        $errors = array_merge($errors, validateInput($rules, 'post'));
        if(empty($errors)) {
            $old_password = $_POST['old_password'];
            $password = $_POST['password'];
            $sid = (int)$_POST['sid'];
            $found_staff = get_table_record_by_col('staffs', ['id' => $sid]);
            if($found_staff) {
                if(password_verify($old_password, $found_staff->password)) {
                    update_db_table('staffs',['password' => password_hash($password, PASSWORD_DEFAULT)], ['id' => $sid]);
                    $info = 'Your password has been changed.';
                } else {
                    $errors['old_password'][] = "Old password is Incorrect";
                }
            } else {
                $info = "Invalid Credentials !";
            }

        }
    }
}
?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Change Password</h1>
        <?php if(!empty($info)): ?>
            <p><?php echo($info) ?></p>
        <?php endif; ?>
        <form action="" method="post">
            <div class="form-group">
                <label for="password">Old Password <span class="error"><?php echo(show_error($errors, 'old_password')) ?></span></label>
                <input class="form-control" type="password" id="password" name="old_password">
            </div>
            <div class="form-group">
                <label for="password">New Password <span class="error"><?php echo(show_error($errors, 'password')) ?></span></label>
                <input class="form-control" type="password" id="password" name="password">
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password <span class="error"><?php echo(show_error($errors, 'confirm_password')) ?></span></label>
                <input class="form-control" type="password" id="confirm_password" name="confirm_password">
            </div>
            <input type="hidden" name="sid" value="<?php echo($sid) ?>">
            <button class="submit-btn" type="submit" name="change">Change Password</button>
        </form>
    </main>
</div>
<?php require_once('../../layouts/footer.php') ?>