<?php
$page_title = 'Manage Students';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $per_page = 10;
    $offset = ($page - 1) * $per_page;
    $sql = "SELECT * FROM `students` ORDER BY `id` DESC LIMIT :per_page OFFSET :offset";
    if(isset($_GET['dept'])) {
        $dept = (int)$_GET['dept'];
        $total_students_count = get_table_records_count('students', ['department' => $dept]);
        $total_pages = ceil($total_students_count / $per_page);
        $sql = "SELECT * FROM `students` WHERE `department` = :dept ORDER BY `id` DESC LIMIT :per_page OFFSET :offset";
    } else {
        $total_students_count = get_table_records_count('students');
        $total_pages = ceil($total_students_count / $per_page);

    }
        try {
            $stmt = $db->prepare($sql);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->bindParam(':per_page', $per_page, PDO::PARAM_INT);
            if(!empty($dept)) {
                $stmt->bindParam(':dept', $dept, PDO::PARAM_INT);
            }
            if($stmt->execute() && $stmt->rowCount() > 0) {
                $students = $stmt->fetchAll(PDO::FETCH_OBJ);
            };
        } catch (PDOException $e) {
        }
    $departments = get_table_records('departments');
}
?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Manage Students</h1>
        <p><?php echo(get_flash_message('info')) ?></p>
        <nav class="sub-menu">
            <form action="" name="filterFrm" method="get">
                <select name="department" class="form-control">
                    <option <?php echo(empty($dept) ? 'selected' : '') ?> disabled>-- All Department --</option>
                    <?php foreach ($departments as $sn => $department): ?>
                        <option value="<?php echo($department->id) ?>" <?php echo (!empty($dept) && $dept === $department->id ? 'selected' : '') ?>><?php  echo($department->department) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="reset" name="reset" class="btn">Clear Filter</button>
            </form>
        </nav>
        <?php if(!empty($students)) { ?>
        <div class="responsive">
        <table>
            <thead>
                <tr>
                    <th>S/N</th>
                    <th>Matric No</th>
                    <th>Fullname</th>
                    <th>Department</th>
                    <th colspan="3">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($students as $pos => $student): ?>
                <tr>
                    <td><?php echo($pos + 1) ?></td>
                    <td><?php echo($student->matric_no) ?></td>
                    <td><?php echo($student->surname . ' '. $student->firstname) ?></td>
                    <td>
                        <?php
                       $departments = get_table_record_by_col('departments', [ 'id' => $student->department ]);
                       echo($departments->department);
                        ?>
                    </td>
                    <td><a href="view-student.php?sid=<?php echo($student->id) ?>">view</a></td>
                    <td><a class="rest_link" data-sid="<?php echo($student->id) ?>" data-action="<?php echo(empty($student->status) ? 'restrict' : 'unrestrict') ?>" href="#"><?php echo(empty($student->status) ? 'restrict' : 'unrestrict') ?></a></td>
                    <td><a href="./student-delete.php?stdID=<?php echo($student->id) ?>&action=delete">delete</a></td>
                </tr>
            <?php endforeach; ?>

            </tbody>
        </table>
        </div>
<!--            Pagination Section-->
            <ul class="pagination">
                <?php if($page > 1): ?>
                    <li><a href="?page=<?php echo($page + 1) ?>">&larr; Prev</a></li>
                <?php endif; ?>
                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                <?php if($i == $page) { ?>
            <li class="active"><a href="?page=<?php echo($i) ?>"><?php echo($i) ?></a></li>
            <?php } else { ?>
                <li><a href="?page=<?php echo($i) ?>"><?php echo($i) ?></a></li>
                <?php } ?>
                <?php endfor; ?>
                <?php if($page < $total_pages): ?>
                    <li><a href="?page=<?php echo($page + 1) ?>"> Next &rarr;</a></li>
                <?php endif; ?>
            </ul>
<!--            End of Pagination -->
        <?php } else { ?>
        <p>No Student Record !</p>
        <?php } ?>
    </main>
</div>
<?php require_once('../../layouts/footer.php') ?>
<script>
    let url = new URL(window.location.href),
        actualLink = `${url.origin}${url.pathname}`,
       filterFrm = document.forms.filterFrm ,
       resetBtn = filterFrm.reset,
        deptSelectField = filterFrm.department;

    deptSelectField.addEventListener('change', (e) => {
        let selectDept = e.target.options[e.target.selectedIndex].value
        let searchParams = url.searchParams
        let newSearchParams = new URLSearchParams()
        newSearchParams.set('dept', selectDept)
        window.location.href = `${actualLink}?${newSearchParams.toString()}`

    })
    resetBtn.addEventListener('click', (e) => {
        window.location.href = `${actualLink}`
    });

    let restrictLink = document.querySelectorAll('.rest_link')
    restrictLink.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault()
            let action = e.target.getAttribute('data-action');
            if(action === 'restrict') {
                confirm('Student will be Restricted and will be unable to register for Exam ?')
            }
            let sid = e.target.getAttribute('data-sid'),             restrictUrl = `../../supports/restrict.php?sid=${sid}&action=${action}`;
            let xhr = new XMLHttpRequest()
            xhr.open('GET', restrictUrl, true)
            xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest')
            xhr.onreadystatechange = () => {
               if(xhr.status == 200 && xhr.readyState == 4) {
                  let responseText = xhr.responseText
                  let resJSON = JSON.parse(responseText)
                  link.setAttribute('data-action', resJSON.action)
                  link.innerHTML = resJSON.action
                }
            }
            xhr.send()
        })
    });
</script>