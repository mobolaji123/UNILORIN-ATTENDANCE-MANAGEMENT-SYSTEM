<?php
$page_title = 'View Student';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $staff = get_table_record_by_col('staffs', [ 'id' => (int)$_SESSION['admin']['sid']]);
    $student = get_table_record_by_col('students', [ 'id' => (int)$_GET['sid']]);
    $registrations = [];
    $historys = get_table_record_by_col('course_registrations', [ 'student_id' => $student->id]);
    if(gettype($historys) === 'object') {
            $registrations[] = $historys;
    } elseif (is_array($historys)) {
        $registrations = $historys;
        }
}
?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Student Bio-Data</h1>
        <nav class="sub-menu">
            <a href="<?php echo($_SERVER['HTTP_REFERER']) ?>">&larr; Back</a>
            <a href="edit-student.php?type=edit&sid=<?php echo($student->id) ?>">Edit Student Info</a>

        </nav>
        <div class="responsive">
        <table>
            <tr>
                <td>Fullname</td>
                <td><?php echo(ucwords(getFullname($student->id))) ?></td>
                <td rowspan="5">
                    <section style="width: 150px; height: 150px; position: relative">
                        <img style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover" src="<?php echo($student->profile_image) ?>" alt="<?php echO($student->firstname) ?>">
                    </section>
                </td>
            </tr>
            <tr>
                <td>Matric No:</td>
                <td><?php echo(strtoupper($student->matric_no)) ?></td>
            </tr>
            <tr>
                <td>Gender</td>
                <td><?php echo($student->gender) ?></td>
            </tr>
            <tr>
                <td>Department</td>
                <td><?php echo(get_table_record_by_col('departments', ['id' => $student->department])->department) ?></td>
            </tr>
            <tr>
                <td>Faculty</td>
                <td>Faculty of Communication and Information Sciences</td>
            </tr>
        </table>
        </div>
        <hr style="margin: 10px 0; border: 1px solid lightgray;">
        <h1>Course Registration History</h1>
<?php if(empty($registrations)) { ?>
        <p>No Registration Yet... !</p>
        <?php } else { ?>
        <div class="responsive">
        <table>
            <thead>
            <tr>
                <th>S/N</th>
                <th>Level</th>
                <th>Approval</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $sn = 1;
            foreach ($registrations as $pos => $registration): ?>
                <tr>
                    <td><?php echo($sn) ?> </td>
                    <td><?php echo($registration->level) ?>L</td>
                    <td>
                        <?php echo($registration->status) ?>
                    </td>
                    <td><a href="./course-detail.file.php?sid=<?php echo(base64_encode('Secret#' . $registration->student_id)) ?>&level=<?php echo(base64_encode('Secure#'. $registration->level)) ?>">view detail</a></td>
                </tr>
                <?php
                $sn++;
            endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php } ?>
    </main>
</div>
<?php require_once('../../layouts/footer.php') ?>
