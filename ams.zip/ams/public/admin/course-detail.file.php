<?php
$page_title = 'Course Registration Details';
require_once '../../vendor/autoload.php';
require_once '../../layouts/admin-partial-header.php';
//QrCode Namespace
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $active_staff = get_table_record_by_col('staffs', ['id' => (int)$_SESSION['admin']['sid']]);
    $encode_id = $_GET['sid'];
    $encode_level = $_GET['level'];
    $decoded_id = base64_decode($encode_id);
    $decoded_level = base64_decode($encode_level);
    $sid = explode('Secret#', $decoded_id)[1];
    $level = explode('Secure#', $decoded_level)[1];
    $student = get_table_record_by_col('students', ['id' => $sid]);
    $course_registrations = get_table_record_by_col('course_registrations', [ 'student_id' => $student->id, 'level' => $level ]);
    $chosen_courses = explode(',', $course_registrations->courses);
    $dept = get_table_record_by_col('departments', [ 'id' => (int)$student->department ])->department;
    $profile_image = !empty($student->profile_image) ? $student->profile_image : '../assets/images/user-ico.png';
    $fullname = $student->firstname . ' ' . $student->surname . ' '. $student->othername;
    $total_chosen_courses = count($chosen_courses);
    $student_data = "
    Matric No: {$student->matric_no},
    Fullname: {$fullname},
    Department: {$dept},
    Level: {$level}L,
    Total Courses Registered: {$total_chosen_courses}
";
    $dataUri = get_table_record_by_col('course_registrations', [ 'student_id' => $student->id, 'level' => $level ])->qr_code;
    if(empty($dataUri)) {
        $writer = new PngWriter();
        $qr_code = new QrCode(
            data: $student_data,
            encoding: new Encoding('UTF-8'),
            errorCorrectionLevel: \Endroid\QrCode\ErrorCorrectionLevel::Low,
            size: 300,
            margin: 10
        );
        $result = $writer->write($qr_code);
        $name = 'Qr_00'. $student->id. time() .'.png';
        $dataUri = $result->getDataUri();
        $sql = "UPDATE `course_registrations` SET `qr_code` = :uri WHERE `student_id` = :id AND `level` = :level";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':uri', $dataUri, PDO::PARAM_STR);
        $stmt->bindParam(':id', $student->id, PDO::PARAM_INT);
        $stmt->bindParam(':level', $level, PDO::PARAM_INT);
        $stmt->execute();
    }


}
?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Admin Dashboard</h1>

        <header id="course-det">
            <section class="logo">
                <img src="../assets/images/logo.png" alt="">
            </section>
            <h1>University of Ilorin</h1>
            <h3>Final Course Registration Form</h3>
        </header>
        <a href="<?php echo($_SERVER['HTTP_REFERER']) ?>"><button class="btn-link">&larr; Go Back</button></a>
        <table id="tab1">
            <tr>
                <th>Reg / Matriculation No</th>
                <td><?php echo($student->matric_no) ?></td>
                <td rowspan="6">
                    <section id="m-profile">
                        <img src="<?php echo($profile_image) ?>" alt="">
                    </section>
                </td>
            </tr>
            <tr>
                <th>Fullname</th>
                <td class="upper"><?php echo(trim(($student->surname . ' ' . $student->firstname . ' '  . $student->othername))) ?></td>
            </tr>
            <tr>
                <th>Faculty</th>
                <td>Faculty of Communication and Information Sciences</td>
            </tr>
            <tr>
                <th>Department</th>
                <td>Department of <?php echo($dept) ?></td>
            </tr>
            <tr>
                <th>Programme</th>
                <td>B.Sc <?php echo($dept) ?></td>
            </tr>
            <tr>
                <th>Current Level</th>
                <td><?php echo($course_registrations->level) ?> Level</td>
            </tr>
        </table>

        <h2 class="text-center">Academic Session: <?php echo($course_registrations->session) ?></h2>
        <table id="tab2">
            <thead>
            <tr>
                <th>Course Code</th>
                <th>Course Title</th>
                <th>Credit Units</th>
                <th>Status</th>
                <th>Approval</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $courses = get_table_record_by_col('courses', [
                'department' => $student->department
            ]);
            $total_units = 0;
            foreach ($courses as $ind => $course):
                if(in_array($course->course_title, $chosen_courses)) {
                $total_units += $course->units;
                ?>

                <tr>
                    <td><?php echo($course->course_code) ?></td>
                    <td><?php echo($course->course_title) ?></td>
                    <td><?php echo($course->units) ?></td>
                    <td><?php echo($course->status) ?></td>
                    <td><?php echo($course_registrations->status) ?></td>
                </tr>
            <?php
                }
                endforeach; ?>
            </tbody>
            <tfoot>
            <tr>
                <?php

                ?>
                <th colspan="5">Total Credit Units: <?php echo($total_units) ?></th>
            </tr>
            </tfoot>
        </table>
        <div class="qr-code">
            <figure>
                <img src="<?php echo($dataUri) ?>" alt="qr_code">
                <figcaption>Scan Me</figcaption>
            </figure>
        </div>

    </main>
</div>
<?php require_once('../../layouts/footer.php') ?>