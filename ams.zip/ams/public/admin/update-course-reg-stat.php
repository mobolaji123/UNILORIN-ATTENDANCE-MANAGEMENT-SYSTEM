<?php
$page_title = 'Dashboard';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $active_staff = get_table_record_by_col('staffs', ['id' => (int)$_SESSION['admin']['sid']]);
    $action = $_GET['action'];
    switch ($action) {
        case 'update':
            $sid = $_GET['sid'];
            $level = $_GET['level'];
            $status = $_GET['status'];
            $sql = "UPDATE `course_registrations` SET `status` = :status WHERE `student_id` = :sid AND `level` = :level LIMIT 1";
            $stmt = $db->prepare($sql);
            $stmt->bindParam(':sid', $sid);
            $stmt->bindParam(':level', $level);
            $stmt->bindParam(':status', $status);
            $stmt->execute();
            header("Location: " . $_SERVER['HTTP_REFERER']);
            break;
        case 'delete':
            $sid = $_GET['sid'];
            $level = $_GET['level'];
            $sql = "DELETE FROM `course_registrations` WHERE `student_id` = :sid AND `level` = :level LIMIT 1";
            $stmt = $db->prepare($sql);
            $stmt->bindParam(':sid', $sid);
            $stmt->bindParam(':level', $level);
            $stmt->execute();
            header("Location: " . $_SERVER['HTTP_REFERER']);
            break;
    }

}


