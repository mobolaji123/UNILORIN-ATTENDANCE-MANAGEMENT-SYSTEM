<?php
$page_title = 'Dashboard';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $active_staff = get_table_record_by_col('staffs', ['id' => (int)$_SESSION['admin']['sid']]);
    $departments_count = get_table_records_count('departments');
    $students_count = get_table_records_count('students');
    $staff_count = get_table_records_count('staffs');
    $total_registration = get_table_records_count('course_registrations');
}
?>
<div id="page">

<!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <h1>Admin Dashboard</h1>
        <div class="card-grid">
            <a href="manage.php?ref=staff">
                <h4>Staffs</h4>
                <span><?php echo($staff_count) ?></span>
                <p>total</p>
            </a>
            <a href="manage.php?ref=department">
                <h4>Department</h4>
                <span><?php echo($departments_count) ?></span>
                <p>total</p>
            </a>
            <a href="manage-student.php">
                <h4>Students</h4>
                <span><?php echo($students_count) ?></span>
                <p>total</p>
            </a>
            <a href="registration.php">
                <h4>Total Registration</h4>
                <span><?php echo($total_registration) ?></span>
                <p>total</p>
            </a>
        </div>
    </main>
</div>
<?php require_once('../../layouts/footer.php') ?>