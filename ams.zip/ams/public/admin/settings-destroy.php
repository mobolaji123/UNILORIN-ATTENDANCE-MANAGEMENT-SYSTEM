<?php
$page_title = 'Exam Attendance Registrations';
require_once '../../layouts/admin-partial-header.php';

if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $action =  $_GET['action'];
    if(!empty($action) && $action == 'delete') {
        $setID = isset($_GET['setID']) ? (int)$_GET['setID'] : '';
        if(!empty($setID)) {
            delete_table_record('attendance_settings', ['id' => $setID]);
            set_flash_message('success', 'info','Settings deleted successfully.');
            header('Location: settings.php');
        }
    }
}
?>
<script>
    window.location.href = 'settings.php';
</script>
