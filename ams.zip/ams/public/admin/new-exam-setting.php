<?php
$page_title = 'Exam Attendance Registrations';
require_once '../../layouts/admin-partial-header.php';

if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $errors = [];
    if(isset($_POST['create'])) {
        $rules = [
            'session' => [
                    'required' => true,
                    'display'=> 'Academic Session'
            ],
            'status' => [
                    'required' => true,
                    'display'=> 'Status'
            ],
            'start_date' => [
                    'required' => true,
                'display'=> 'Start Date'
            ],
            'close_date' => [
                    'required' => true,
                'display'=> 'Close Date'
            ]
        ];
        setDefault(['status']);
        $errors = array_merge($errors, validateInput($rules, 'post'));
        if(empty($errors)) {
            if(add_to_db_table('attendance_settings', [
                'status' => $_POST['status'],
               'session' => clean_string($_POST['session']),
               'open_at' => format_date($_POST['start_date'], "Y-m-d H:i:s"),
               'close_at' => format_date($_POST['close_date'], "Y-m-d H:i:s")
            ])) {
               set_flash_message('success', 'info', "Exam settings added successfully");
               header('Location: ./settings.php');
            }
        }
    }

}

?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <main class="content">
        <nav class="sub-menu">
            <a href="<?php echo($_SERVER['HTTP_REFERER']) ?>" class="btn">&larr; Back</a>
        </nav>
        <h1>Creat New Exam Attendance Registration</h1>
        <form method="POST" action="">
            <div class="form-group">
                <label for="session">Academic Session <span class="error"><?php echo(show_error($errors, 'session')) ?></span></label>
                <input type="text" id="session" name="session" class="form-control" value="<?php echo(old('session')) ?>" />
            </div>
            <div class="form-group">
                <label for="status">Status <span class="error"><?php echo(show_error($errors, 'status')) ?></span></label>
                <?php $selectedStatus = old('status') ?>
                <select name="status" id="status" class="form-control">
                    <option disabled <?php echo(empty($selectedStatus) ? 'selected' : ''); ?>>-- Choose Status --</option>
                    <option value="open" <?php echo($selectedStatus === 'open' ? 'selected' : '') ?>>Open</option>
                    <option value="closed" <?php echo($selectedStatus === 'closed' ? 'selected' : '') ?>>Closed</option>
                </select>
            </div>
            <div class="form-group">
                <label for="start">Start Date <span class="error"><?php echo(show_error($errors, 'start_date')) ?></span></label>
                <input class="form-control" type="datetime-local" name="start_date" id="start" value="<?php echo(old('start_date')) ?>">
            </div>
            <div class="form-group">
                <label for="close">Close Date <span class="error"><?php echo(show_error($errors, 'close_date')) ?></span></label>
                <input value="<?php echo(old('close_date')) ?>" class="form-control" type="datetime-local" name="close_date" id="close">
            </div>
            <button type="submit" class="submit-btn" name="create">Submit</button>

        </form>
    </main>


</div>
<?php require_once('../../layouts/footer.php') ?>