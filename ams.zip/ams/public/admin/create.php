<?php
$page_title = 'Create Staff Account';
require_once '../../layouts/admin-partial-header.php';
if(!validate_staff_logged_in()) {
    redirectTo('./login.php');
} else {
    $id = isset($_GET['sid']) ? (int)$_GET['sid']: null;
    $type = isset($_GET['type']) ? $_GET['type'] : null;
    $active_staff = get_table_record_by_col('staffs', ['id' => (int)$_SESSION['admin']['sid']]);
    $errors = [];
    if(isset($_POST['create'])) {
        $fields = [
            'fullname' => [
                'display' => 'Full Name',
                'required' => true,
                'min' => 3,
                'max' => 50,
            ],
            'email' => [
                'display' => 'E-mail Address',
                'required' => true,
                'unique' => true
            ],
            'password' => [
                'display' => 'Password',
                'required' => true,
                'min' => 8,
            ],
            'confirm_password' => [
                'display' => 'Confirm Password',
                'required' => true,
                'match' => 'password',
            ],
            'phone' => [
                'display' => 'Phone Number',
                'required' => true,
                'min' => 11,
                'unique' => true
            ],
            'employmentType' => [
                'display' => 'Employment Type',
                'required' => true,
            ]
        ];
        setDefault(['employmentType']);
        $errors = array_merge($errors, validateInput($fields, 'post', 'staffs'));
        if(empty($errors)) {
            $fullname = clean_string($_POST['fullname']);
            $email = $_POST['email'];
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $phone = clean_string($_POST['phone']);
            $employmentType = clean_string($_POST['employmentType']);
            add_to_db_table('staffs', [
                    'fullname' => $fullname,
                    'email' => $email,
                    'password' => $password,
                    'phone' => $phone,
                    'employeeType' => $employmentType
            ]);
            set_flash_message('success', 'info','Staff Account Created !');
            header('Location: manage.php?ref=staff');
        }
    }
    if(isset($_POST['update'])) {
        $rules = [
            'fullname' => [
                'display' => 'Full Name',
                'required' => true,
                'min' => 3,
                'max' => 50,
            ],
            'email' => [
                'display' => 'E-mail Address',
                'required' => true,
            ],
            'phone' => [
                'display' => 'Phone Number',
                'required' => true,
                'min' => 11
            ],
            'employmentType' => [
                'display' => 'Employment Type',
                'required' => true,
            ]
        ];
        $errors = array_merge($errors, validateInput($rules, 'post', 'staffs'));
        if(empty($errors)) {
            update_db_table('staffs', [
                'fullname' => $_POST['fullname'],
                'email' => $_POST['email'],
                'phone' => $_POST['phone'],
                'employeeType' => $_POST['employmentType']
            ], ['id' => (int)$_POST['sid']]);
            set_flash_message('success', 'info', "Staff information successfully updated");
            header('location: manage.php?ref=staff');
        }

    }
}

?>
<div id="page">
    <!--    Include Navigation -->
    <?php require_once ('./partials/navigation.php') ?>
    <?php if($type === 'new') { ?>
    <main class="content">
        <h1>Create New Staff Account</h1>
        <form method="POST">

            <div class="form-group">
                <label for="name">Fullname <span class="error"><?php echo(show_error($errors, 'fullname')) ?></span></label>
                <input class="form-control" type="text" id="name" name="fullname" value="<?php echo(old('fullname')) ?>" placeholder="Enter your Fullname" pattern="[a-zA-Z]{4,50}" >
            </div>
            <div class="form-group">
                <label for="email">E-mail <span class="error"><?php echo(show_error($errors, 'email')) ?></span></label>
                <input class="form-control" type="email" id="email" name="email" value="<?php echo(old('email')) ?>" placeholder="Enter your E-mail address">
            </div>
            <div class="form-group">
                <label for="password">Password <span class="error"><?php echo(show_error($errors, 'password')) ?></span></label>
                <input class="form-control" type="password" id="password" name="password">
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password <span class="error"><?php echo(show_error($errors, 'confirm_password')) ?></span></label>
                <input class="form-control" type="password" id="confirm_password" name="confirm_password">
            </div>
            <div class="form-group">
                <label for="phone">Phone No <span class="error"><?php echo(show_error($errors, 'phone')) ?></span></label>
                <input class="form-control" type="tel" id="phone" name="phone" pattern="[0-9]{11}" value="<?php echo(old('phone')) ?>">
            </div>
            <div class="form-group">
                <label for="empType">Employment Type <span class="error"><?php echo(show_error($errors, 'employmentType')) ?></span></label>
                <select class="form-control" name="employmentType" id="empType">
                    <?php $old_employeementType = old('employmentType'); ?>
                    <option disabled <?php echo(empty($old_employeementType) ? 'selected' : '') ?>>-- Choose your Employment Type --</option>
                    <option value="teaching staff" <?php echo($old_employeementType == 'teaching staff' ? 'selected' : '') ?>>Teaching Staff</option>
                    <option value="non teaching staff" <?php echo($old_employeementType == 'non teaching staff' ? 'selected' : '') ?>>Non Teaching Staff</option>
                </select>
            </div>
            <button type="submit" class="submit-btn" name="create">Create Account</button>

        </form>
    </main>
    <?php

    } elseif($type === 'edit') {if($type === 'edit') {
        $staff = get_table_record_by_col('staffs', [ 'id' => $id ]);
    }
    ?>
        <main class="content">
            <h1>Edit Staff Information</h1>
            <form method="POST">
                <input type="hidden" name="sid" value="<?php echo($staff->id) ?>">
                <div class="form-group">
                    <label for="name">Fullname <span class="error"><?php echo(show_error($errors, 'fullname')) ?></span></label>
                    <input class="form-control" type="text" id="name" name="fullname" placeholder="Enter your Fullname" value="<?php echo($staff->fullname) ?>" >
                </div>
                <div class="form-group">
                    <label for="email">E-mail <span class="error"><?php echo(show_error($errors, 'email')) ?></span></label>
                    <input class="form-control" type="email" id="email" name="email" placeholder="Enter your E-mail address" value="<?php echo($staff->email) ?>">
                </div>
                <div class="form-group">
                    <label for="phone">Phone No <span class="error"><?php echo(show_error($errors, 'phone')) ?></span></label>
                    <input class="form-control" type="tel" id="phone" name="phone" value="<?php echo($staff->phone) ?>">
                </div>
                <div class="form-group">
                    <label for="empType">Employment Type <span class="error"><?php echo(show_error($errors, 'employmentType')) ?></span></label>
                    <select class="form-control" name="employmentType" id="empType">
                        <?php $employmentType = $staff->employmentType; ?>
                        <option value="teaching staff" <?php echo($employmentType === 'teaching staff' ? 'selected' : '') ?>>Teaching Staff</option>
                        <option value="non teaching staff" <?php echo($employmentType === 'non teaching staff' ? 'selected' : '') ?>>Non Teaching Staff</option>
                    </select>
                </div>
                <button type="submit" class="submit-btn" name="update">Update Info</button>
            </form>
        </main>
    <?php } ?>
</div>
<?php require_once('../../layouts/footer.php') ?>