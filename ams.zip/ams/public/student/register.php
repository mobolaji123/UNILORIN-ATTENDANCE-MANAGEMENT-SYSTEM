<?php
$page_title = "Sign Up";
require_once '../../layouts/student-header.php';
if(validate_student_logged_in()) {
    redirectTo('./dashboard.php');
}
$form_errors = array();
if(isset($_POST["submit"])) {

    setDefault(['gender', 'department'], 'post');
    $field_rules = array(
            'matric_no' => [
                    'required' => true,
                    'unique' => true,
                    'display' => 'Matric No'
            ],
            'surname' => [
                'required' => true,
                'min' => 4,
                'max' => 50,
                'display' => 'Surname'
            ],
            'firstname' => [
                'required' => true,
                'min' => 4,
                'max' => 50,
                'display' => 'First Name'
            ],
            'othername' => [
                'min' => 4,
                'max' => 50,
                'display' => 'Other Name'
            ],
            'gender' => [
                    'required' => true,
                    'display' => 'Gender'
            ],
            'department' => [
                'required' => true,
                'display' => 'Department'
            ]
    );
    $form_errors = array_merge($form_errors, validateInput($field_rules, 'post'));
    if(empty($_FILES['passport']['name'])) {
        $form_errors[ 'passport'][] = 'Please Choose a Passport Photograph';
    }
    if(!empty($_FILES)) {
        $passport = validate_image_file($_FILES['passport']['name']);
        if($passport === false) {
            $form_errors[ 'passport'][] = 'Only Supported PNG, JPG and JPEG files are allowed';
        }
    }
    if(empty($form_errors)) {
        $path = "../assets/uploads/images/";
        $path_partial =  date('Y') . "/" . date('m') . "/" . date('d');
        $full_path = $path . $path_partial;
        createFolder($full_path);
        $profile_img = ($full_path . '/' . $passport);

        if(move_uploaded_file($_FILES['passport']['tmp_name'], $profile_img)) {
            $student_data = [
                'matric_no' => trim($_POST["matric_no"]),
                'surname' => clean_string($_POST["surname"]),
                'firstname' => clean_string($_POST["firstname"]),
                'othername' => clean_string($_POST["othername"]),
                'gender' => $_POST["gender"],
                'department' => $_POST["department"],
                'password' => password_hash(strtolower(trim($_POST["surname"])), PASSWORD_DEFAULT),
                'profile_image' => $profile_img
            ];
            $passport = $_POST["passport"];
            if(add_to_db_table('students', $student_data)) {
                set_flash_message('success', 'info', 'Student Registered Successfully');
                header('location: ./login.php');
            }
        } else{
            echo('An Error Occurred !');
        }

    }
}
?>
    <main id="reg-main">
        <div id="intro">
            <div class="content">
                <h1>Welcome to Student Portal</h1>
                <p>How to Access the System</p>
                <p>Ensure to register as a student, then login with your Matric No and your surname as the Password</p>
            </div>
        </div>
        <div id="form-area">
            <form action="" method="post" name="regForm" enctype="multipart/form-data">
                <h4>Registration Form</h4>
                <?php if(!empty($message)): ?>
                <p><?php echo $message; ?></p>
                <?php endif; ?>
                <div class="form-group">
                    <label for="username">Matric No <span class="error"><?php echo(show_error($form_errors, 'matric_no')) ?></span></label>
                    <input type="text" class="form-control" name="matric_no" id="username" placeholder="Matric No" value="<?php echo(old('matric_no')) ?>">
                </div>
                <div class="form-group">
                    <label for="surname">Surname <span class="error"><?php echo(show_error($form_errors, 'surname')) ?></span></label>
                    <input type="text" class="form-control" name="surname" id="surname" value="<?php echo(old('surname')) ?>" pattern="[a-zA-Z]{3,20}">
                </div>
                <div class="form-group">
                    <label for="firstname">Firstname <span class="error"><?php echo(show_error($form_errors, 'firstname')) ?></span></label>
                    <input type="text" class="form-control" name="firstname" id="firstname" value="<?php echo(old('firstname')) ?>" pattern="[a-zA-Z]{3,20}">
                </div>
                <div class="form-group">
                    <label for="other">Othername <span class="error"><?php echo(show_error($form_errors, 'othername')) ?></span></label>
                    <input class="form-control" type="text" name="othername" id="other" value="<?php echo(old('othername')) ?>" pattern="[a-zA-Z]{3,20}">
                </div>
                <div class="form-group">
                    <label for="gender">Gender <span class="error"><?php echo(show_error($form_errors, 'gender')) ?></span></label>
                    <select name="gender" id="gender" class="form-control">
                        <?php $old_gender = old('gender'); ?>
                        <option disabled <?php echo(empty($old_gender) ? 'selected' : '') ?>>-- choose your gender --</option>
                        <option value="male" <?php echo($old_gender === 'male' ? 'selected' : '') ?>>Male</option>
                        <option value="female" <?php echo($old_gender === 'female' ? 'selected' : '') ?>>Female</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="dpmt">Department <span class="error"><?php echo(show_error($form_errors, 'department')) ?></span></label>
                    <select name="department" id="dpmt" class="form-control">
                        <?php $dpmt = get_table_records('departments') ?>
                        <?php $old_dept = old('department') ?>
                        <option disabled <?php echo(empty($old_dept) ? 'selected' : '') ?>>-- choose your Department --</option>
                        <?php foreach ($dpmt as $dpt): ?>
                            <option value="<?php echo($dpt->id) ?>" <?php echo((int)$old_dept === $dpt->id ? 'selected' : '')  ?>><?php echo($dpt->department); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="passport">Passport Photograph <span class="error"><?php echo(show_error($form_errors, 'passport')) ?></span></label>
                    <input class="form-control" type="file" name="passport" id="passport">
                </div>
                <button type="submit" class="btn" name="submit">Sign Up</button>
            </form>
        </div>
    </main>
<?php require_once '../../layouts/student-footer.php' ?>