<?php
$page_title = "Profile";
require_once '../../layouts/student-header.php';
if(!validate_student_logged_in()) {
    redirectTo('./login.php');
} else if(!empty($_SESSION['student']['sid'])) {
    $active_student = get_table_record_by_col('students', [ 'matric_no' => $_SESSION['student']['sid'] ]);
    $fullname = $active_student->firstname . ' ' . $active_student->surname . ' '. $active_student->othername;
    $profile_image = !empty($active_student->profile_image) ? $active_student->profile_image : '../assets/images/user-ico.png';
}
?>

<main id="dashboard-main" class="student-area">
    <!--    Sidebar -->
    <?php require_once('./partials/sidebar.php') ?>
    <section class="main-area">
        <h1>Profile Information</h1>
       <table border="1" id="profile1">
           <tr>
               <th>Reg/Matriculation No</th>
               <td><b><?php echo(strtoupper($active_student->matric_no)) ?></b></td>
               <td rowspan="4">
                   <section class="profile-image">
                       <img src="<?php echo($profile_image) ?>" alt="logo">
                   </section>
                   <a href="./upload.php" class="btn">
                       <button style="color: #fff; display: flex; justify-content: center">Change Photo</button>
                   </a>
               </td>
           </tr>
           <tr>
               <th>Full Name</th>
               <td><b><?php echo(strtoupper($fullname)) ?></b></td>
           </tr>
           <tr>
               <th>Department</th>
               <?php $department = get_table_record_by_col('departments', ['id' => $active_student->department]) ?>
               <td><b><?php echo($department->department) ?></b></td>
           </tr>
           <tr>
               <th>Gender</th>
               <td><b><?php echo(ucfirst($active_student->gender)) ?></b></td>
           </tr>

       </table>
        <div id="profile2">
            <section class="profile-image" style="width: 200px; height: 200px; position: relative">
                <img style="position: absolute; width: 100%; height: 100%; top: 0; left: 0; object-fit: cover" src="<?php echo($profile_image) ?>" alt="logo">
            </section>
            <a href="./upload.php" class="btn" style="width: 200px">
                <button style="color: #fff;">Change Photo</button>
            </a>
            <br>
           <p><b>Reg/Matriculation No</b>: <span style="font-weight: 400"><?php echo(strtoupper($active_student->matric_no)) ?></span></p>
            <p><b>Fullname</b>: <span style="font-weight: 400"><?php echo(strtoupper($fullname)) ?></span></p>
            <p><b>Department</b>: <span style="font-weight: 400"><?php echo($department->department) ?></span></p>
            <p><b>Gender</b>: <span style="font-weight: 400"><?php echo(ucfirst($active_student->gender)) ?></span></p>
        </div>
    </section>
</main>
<?php require_once '../../layouts/student-footer.php' ?>
