<div id="sidebar" class="slideLeft">
    <nav>
        <ul>
            <li><a href="./dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="./profile.php"><i class="fa fa-user"></i> Profile</a></li>
            <li><a href="./manage-course.php"><i class="fa fa-book-atlas"></i> Manage Course Registration</a></li>
            <li><a href="./logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </nav>
</div>