<?php
$page_title = "Sign In";
require_once '../../layouts/student-header.php';
if(validate_student_logged_in()) {
    redirectTo('./dashboard.php');
}
if(isset($_POST['login'])) {
    $matric_no = $_POST['username'];
    $password = $_POST['password'];
    $user = authenticate_student($matric_no, $password);
    if($user) {
        $user_status = $user->status;
        if($user_status === 'restrict') {
            $message = "You are restricted to access this page. kindly contact the administrator.";
        } else {
            $_SESSION['student']['sid'] = $user->matric_no;
            redirectTo('./dashboard.php');
        }
    } else {
        $message = "Wrong username or password";
    }
}
?>

<main id="login-main">
    <div class="form-area">
        <form action="" method="post" name="loginFrm">
            <h4>Login Form</h4>
            <p class="error"><?php echo(get_flash_message('info')) ?></p>
            <?php if(isset($message)) { ?>
                <p class="error">Info: <?php echo($message) ?></p>
            <?php } ?>
            <div class="form-group">
                <label for="username">Matric No</label>
                <input type="text" name="username" id="username" placeholder="Matric No" class="form-control" value="<?php echo(old('username')) ?>">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" id="password">
            </div>
            <p>
                <label>
                    <input type="checkbox" value="keep me login"> keep me login
                </label>
            </p>
            <button class="btn" type="submit" name="login">Sign In</button>
        </form>
    </div>
</main>
<?php require_once '../../layouts/student-footer.php' ?>
