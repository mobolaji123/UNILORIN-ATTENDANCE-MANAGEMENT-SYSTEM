<?php
$page_title = "Student Home";
require_once '../../layouts/student-header.php';
if(validate_student_logged_in()) {
    redirectTo('dashboard.php');
}
?>

<main id="home-main">
    <div id="hero" class="owl-carousel owl-theme">
        <section class="item">
            <img src="../assets/images/hero-01.jpg" alt="Hero bg 1">
        </section>
        <section class="item">
            <img src="../assets/images/hero-02.jpg" alt="Hero Bg 2">
        </section>
    </div>
    <section id="about">
        <h1>Attendance Management System</h1>
        <p>The Primary Objective of this project are to eliminate manual errors, enhance efficiency and provide insightful analytics on attendance patterns. By implementing this solution, institutions can improve accountability, reduce fraud and enhance productivity.</p>
    </section>
</main>
<?php require_once '../../layouts/student-footer.php' ?>
