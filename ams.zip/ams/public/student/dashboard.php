<?php
$page_title = "Dashboard";
require_once '../../layouts/student-header.php';
if(!validate_student_logged_in()) {
    redirectTo('./login.php');
} else if(!empty($_SESSION['student']['sid'])) {
    $active_student = get_table_record_by_col('students', [ 'matric_no' => $_SESSION['student']['sid'] ]);

}
?>

<main id="dashboard-main" class="student-area">
<!--    Sidebar -->
    <?php require_once('./partials/sidebar.php') ?>
    <section class="main-area">
        <h1>Dashboard</h1>
        <p>Welcome, <?php echo(ucfirst($active_student->firstname)) ?></p>

    </section>
</main>
<?php require_once '../../layouts/student-footer.php' ?>
