<?php
$page_title = "Profile";
require_once '../../layouts/student-header.php';
if(!validate_student_logged_in()) {
    redirectTo('./login.php');
} else if(!empty($_SESSION['student']['sid'])) {
    $active_student = get_table_record_by_col('students', [ 'matric_no' => $_SESSION['student']['sid'] ]);
    $errors = [];
    if(isset($_POST['upload'])) {
        $photo = $_FILES['photo']['name'];
        $file_ext = pathinfo($photo, PATHINFO_EXTENSION);
        $accept = ['jpg', 'jpeg', 'png'];
        if(!in_array($file_ext, $accept)) {
            $errors[] = "Please upload a valid image file. (." . $file_ext . ") are not allowed.";
        } else {
            if($_FILES['photo']['size'] > 10200) {
                $errors[] = "Sorry, your file is too large.";
            }
            $path = '../assets/uploads/images/';
            $new_dir = date('Y') . '/' . date('m') . '/' . date('d');
            $path = $path . $new_dir;
            if(!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $new_name = date('Y') . '_' . date('m') . '_' . date('d') . '_' . uniqid() . '.' . $file_ext;
            $filename = $path . '/'. $new_name;
            move_uploaded_file($_FILES['photo']['tmp_name'], $filename);
            update_db_table('students', [ 'profile_image' => $filename ], ['id' => $active_student->id]);
            redirectTo('./profile.php');
        }

    }
}
?>

<main id="dashboard-main" class="student-area">
    <!--    Sidebar -->
    <?php require_once('./partials/sidebar.php') ?>
    <section class="main-area">
       <h1>Profile Photo Upload</h1>
        <?php if(!empty($errors)): ?>
        <p>Please note the following Error !</p>
        <ul>
            <?php foreach($errors as $error): ?>
                <li><?php echo($error) ?></li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
        <form action="" enctype="multipart/form-data" method="post">
            <div class="form-group">
                <label for="passport">Passport Photo</label>
                <input class="form-control" accept="image/*" type="file" name="photo">
            </div>
            <button name="upload" type="submit" class="btn">Upload</button>
        </form>
    </section>
</main>
<?php require_once '../../layouts/student-footer.php' ?>
