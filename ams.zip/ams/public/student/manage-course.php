<?php
$page_title = "Manage Course Registration";
require_once '../../layouts/student-header.php';
if(!validate_student_logged_in()) {
    redirectTo('./login.php');
} else if(!empty($_SESSION['student']['sid'])) {
    $active_student = get_table_record_by_col('students', [ 'matric_no' => $_SESSION['student']['sid'] ]);
    $course_registrations = get_table_record_by_col('course_registrations', [ 'student_id' => $active_student->id ]);
    $registrations = [];
    if(gettype($course_registrations) == 'object') {
        $registrations[] = $course_registrations;
    } elseif (is_array($course_registrations)) {
        $registrations = $course_registrations;
    }
}

?>

<main id="dashboard-main" class="student-area">
    <!--    Sidebar -->
    <?php require_once('./partials/sidebar.php') ?>
    <section class="main-area">
        <div id="manage-course">
            <header>
                <nav class="top-menu">
                    <a href="./new-registration.php">New Registration</a>
                </nav>
            </header>
            <h1>Course Registration History</h1>
    <p>Found (<?php echo(count($registrations)) ?>) Previous Record</p>
      <?php if(!empty($registrations)) { ?>
              <div class="table-responsive">
       <table>
           <thead>
              <tr>
                 <th>S/N</th>
                 <th>Department</th>
                 <th>Level</th>
                 <th>Approval</th>
                 <th>Created At</th>
                 <th>Action</th>
              </tr>
           </thead>
           <tbody>
                <?php foreach ($registrations as $pos => $register): ?>
                 <tr>
                     <td><?php echo($pos + 1) ?></td>
                     <td><?php echo(get_table_record_by_col('departments', ['id' => $active_student->department])->department) ?></td>
                     <td><?php echo($register->level . 'L') ?></td>
                     <td><?php echo($register->status) ?></td>
                     <td><?php echo(format_date($register->created_at, 'F j, Y h:i:s a')); ?></td>
                     <td>
                        <a href="./course-registration-detail.php?crid=<?php echo($register->id) ?>" class="btn">view</a>
                     </td>
                 </tr>
                    <?php endforeach; ?>
           </tbody>
       </table>
              </div>
       <?php } else { ?>
                <p>No Course Registration Records Found !</p>
            <?php } ?>
        </div>
    </section>
</main>
<?php require_once '../../layouts/student-footer.php' ?>
