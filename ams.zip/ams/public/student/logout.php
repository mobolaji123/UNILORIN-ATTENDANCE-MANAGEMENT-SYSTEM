<?php
require_once '../../layouts/student-header.php';
if(isset($_SESSION['student'])){
    unset($_SESSION['student']);
    session_destroy();
}
redirectTo("./login.php");