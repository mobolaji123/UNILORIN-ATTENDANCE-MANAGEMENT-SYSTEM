<?php
$page_title = "Manage Course Registration";
require_once '../../layouts/student-header.php';
if(!validate_student_logged_in()) {
    redirectTo('./login.php');
} else if(!empty($_SESSION['student']['sid'])) {
    $active_student = get_table_record_by_col('students', [ 'matric_no' => $_SESSION['student']['sid'] ]);
    $fullname = $active_student->firstname . ' ' . $active_student->surname . ' '. $active_student->othername;
    $department = get_table_record_by_col('departments', [ 'id' => $active_student->department ]);
    $courses = get_table_record_by_col('courses', ['department' => $department->id ]);
    $levels = get_unique_level_dept((int)$active_student->department);

//    Get the Latest Attendance Settings
    try {
       $sql = "SELECT * FROM `attendance_settings` WHERE `status` = 'open' AND `close_at` >= NOW() ORDER BY `id` DESC LIMIT 1";
       $db->prepare($sql);
       $stmt = $db->query($sql);
       $stmt->execute();
       $active_open_register = $stmt->fetch(PDO::FETCH_OBJ);
    }catch (PDOException $e) {
        die($e->getMessage());
    }
    if(!empty($active_open_register)) {
        $session = $active_open_register->session;
        $already_registered = get_table_records_count('course_registrations', [ 'session' => $session, 'student_id' => $active_student->id ]);
    }
    $errors = [];

    if(isset($_POST['register'])) {

        setDefault(['level']);
        $rules = [
                'level' => [
                    'required' => true,
                    'display' => 'Level'
                ]
        ];
        $errors = array_merge($errors, validateInput($rules, 'post'));
        if(empty($_POST['courses'])) {
            $errors['courses'][] = 'Courses for Selected Level are required.';
        }
        if(empty($errors)) {
            $level = (int)$_POST['level'];
            $session = $_POST['session'];
            $selected_courses = implode(',', $_POST['courses']);
            add_to_db_table('course_registrations', [
                'student_id' => $active_student->id,
                'department_id' => $department->id,
                'level' => $level,
                'session' => $session,
                'courses' => $selected_courses,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            $_SESSION['info'] = 'Course Registration Successful';
            header('location: manage-course.php');
        }
    }
}
?>

<main id="dashboard-main" class="student-area">
    <!--    Sidebar -->
    <?php require_once('./partials/sidebar.php') ?>
    <section class="main-area">
        <h1>Course Registration Form</h1>
    <?php if(empty($active_open_register)){ ?>
<h1>Registration is Closed for Now !. Kindly Checked back some other Time</h1>
<?php } else { ?>
            <?php if($already_registered === 1) { ?>
<h1>Hooray !</h1>
 <p>You already registered for this Semester Examination, you can check your registration history to print out you Registration Slip</p>
<p>See you again next Semester</p>
<p>Good Luck with you Examination !</p>
             <?php } elseif (empty($already_registered)) { ?>
        <form action="" name="courseReg" method="post">
            <div class="form-group">
                <label for="fullname">Fullname</label>
                <input type="text" name="fullname" value="<?php echo(strtoupper($fullname)) ?>" id="fullname" readonly class="form-control">
            </div>
            <div class="form-group">
                <label for="dept">Department</label>
                <input type="text" readonly name="department" class="form-control" id="dept" value="<?php echo($department->department) ?>" data-id="<?php echo($department->id) ?>">
            </div>
            <div class="form-group">
                <label for="level" >Level <span class="error"><?php echo(show_error($errors, 'level')) ?></span></label>
                <select name="level" id="level" required class="form-control">
                    <option disabled selected>-- Choose Level --</option>
        <?php foreach($levels as $pos => $level): ?>
            <option value="<?php echo($level->level) ?>"><?php echo($level->level) ?>L</option>
        <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="" >Academic Session</label>
                <input type="text" placeholder="2020/2021" class="form-control" value="<?php echo($active_open_register->session) ?>" name="session" readonly>
            </div>
            <div class="form-group">
                <label for="">Courses <span class="error"><?php echo(show_error($errors, 'courses')) ?></span></label>
                <div class="courses form-group">
                    <?php if(count($courses)): ?>
                        <?php foreach ($levels as $pos => $level): ?>
                            <h4><?php echo($level->level) ?>L</h4>
                            <?php foreach($courses as $course): ?>
                                <?php if($course->level === $level->level) { ?>
                                    <section>
                                        <input name="courses[]" type="checkbox" value="<?php echo($course->course_title) ?>" id="<?php echo($course->course_title) ?>" >
                                        <label for="<?php echo($course->course_title) ?>"><?php echo($course->course_title) ?></label>
                                    </section>
                                <?php } ?>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <button type="submit" name="register" class="btn submit-btn">Register</button>
        </form>
                <?php } ?>
        <?php } ?>
    </section>
</main>
<?php require_once '../../layouts/student-footer.php' ?>
<script>
   // const form = document.forms.courseReg,
   //       departmentId = form.department.getAttribute('data-id'),
   //       levelField = form.level,
   //       coursesDiv = document.querySelector('.courses');
   // levelField.addEventListener('change', (e) => {
   //     let selectedLevel = e.target.options[e.target.selectedIndex].value
   //     let url = `../../supports/courses.php?level=${selectedLevel}&dpt=${departmentId}`
   //     let xhr = new XMLHttpRequest();
   //     console.log(url)
   //     xhr.open('GET', url, true)
   //     xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest')
   //     coursesDiv.innerHTML = '';
   //     xhr.onreadystatechange = function () {
   //         if(xhr.readyState == 4 && xhr.status == 200 ) {
   //             let response = xhr.responseText
   //             let courses = JSON.parse(response)
   //             console.log(courses)
   //             courses.map(course => {
   //                 let { course_title, status } = course
   //                 let section = document.createElement('section'),
   //                     input = document.createElement('input'),
   //                     label = document.createElement('label');
   //                 input.setAttribute('type', 'checkbox')
   //                 input.setAttribute('id', `${course_title}`)
   //                 input.setAttribute('value', `${course_title}`)
   //                 label.setAttribute('for', `${course_title}`)
   //                 label.innerHTML = `${course_title}`
   //                 if(status.toLowerCase() === 'core') {
   //                     input.setAttribute('checked', 'true');
   //                     input.setAttribute('disabled', 'true')
   //                 }
   //                  section.appendChild(input)
   //                 section.appendChild(label)
   //                 coursesDiv.appendChild(section)
   //             })
   //         }
   //     }
   //     xhr.send()
   // })
</script>