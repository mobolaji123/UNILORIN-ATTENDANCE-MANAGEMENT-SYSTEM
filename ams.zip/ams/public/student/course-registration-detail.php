<?php
$page_title = "Course Registration Details";
require_once '../../layouts/student-header.php';
if(!validate_student_logged_in()) {
    redirectTo('./login.php');
} else if(!empty($_SESSION['student']['sid'])) {
    $active_student = get_table_record_by_col('students', [ 'matric_no' => $_SESSION['student']['sid'] ]);
    $crid = (int)$_GET['crid'];
    $course_registrations = get_table_record_by_col('course_registrations', [ 'id' => $crid ]);
    $dept = get_table_record_by_col('departments', [ 'id' => (int)$active_student->department ])->department;
    $profile_image = !empty($active_student->profile_image) ? $active_student->profile_image : '../assets/images/user-ico.png';
    $chosen_courses = explode(',', trim($course_registrations->courses));
}
?>

<main id="dashboard-main" class="student-area">
    <!--    Sidebar -->
    <?php require_once('./partials/sidebar.php') ?>
    <section class="main-area">
        <div id="manage-course">
            <header>
                <nav class="top-menu">
                    <a href="./course-detail-file.php?sid=<?php echo(base64_encode('Secret#'.$active_student->id)) ?>&level=<?php echo(base64_encode('Secure#'. $course_registrations->level)) ?>" target="_blank">Print</a>
                </nav>
            </header>
            <h1>University of Ilorin</h1>
            <h3>Final Course Registration Form</h3>
            <table>
                <tr>
                    <th>Reg / Matriculation No</th>
                    <td><?php echo($active_student->matric_no) ?></td>
                    <td rowspan="6">
                        <section class="profile-image">
                            <img src="<?php echo($profile_image) ?>" alt="">
                        </section>
                    </td>
                </tr>
                <tr>
                    <th>Fullname</th>
                    <td><?php echo(trim(($active_student->surname . ' ' . $active_student->firstname . ' '  . $active_student->othername))) ?></td>
                </tr>
                <tr>
                    <th>Faculty</th>
                    <td>Faculty of Communication and Information Sciences</td>
                </tr>
                <tr>
                    <th>Department</th>
                    <td>Department of <?php echo($dept) ?></td>
                </tr>
                <tr>
                    <th>Programme</th>
                    <td>B.Sc <?php echo($dept) ?></td>
                </tr>
                <tr>
                    <th>Current Level</th>
                    <td><?php echo($course_registrations->level) ?> Level</td>
                </tr>
            </table>

            <h2>Academic Session: <?php echo($course_registrations->session) ?></h2>
            <table>
                <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Credit Units</th>
                    <th>Status</th>
                    <th>Approval</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $courses = get_table_record_by_col('courses', [
                        'department' => $active_student->department
                ]);
                $total_units = 0;
                foreach ($courses as $ind => $course):
                    if(in_array($course->course_title, $chosen_courses)) {
                    $total_units += $course->units;
                ?>

                <tr>
                    <td><?php echo($course->course_code) ?></td>
                    <td><?php echo($course->course_title) ?></td>
                    <td><?php echo($course->units) ?></td>
                    <td><?php echo($course->status) ?></td>
                    <td><?php echo($course_registrations->status) ?></td>
                </tr>
                <?php
                    }
                endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <?php

                        ?>
                        <th colspan="5">Total Credit Units: <?php echo($total_units) ?></th>
                    </tr>
                </tfoot>
            </table>
    </section>
</main>
<?php require_once '../../layouts/student-footer.php' ?>
