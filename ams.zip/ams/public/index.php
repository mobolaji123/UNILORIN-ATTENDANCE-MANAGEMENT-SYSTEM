<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>AMS</title>
    <link rel="stylesheet" href="./css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Segoe UI", Arial;
            font-weight: 300;
            font-size: 100%;
            text-decoration: none;
            color: black;
            border: none;
            outline: none;
            background-color: transparent;
        }
        #intro {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            background-image: linear-gradient(rgba(255, 0, 0, .2), black), url("./assets/images/hero-02.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        #intro > section {
            width: 75%;
        }
        #intro h1 {
            font-size: 3rem;
            font-weight: 900;
            color: white;
            text-shadow: 1px 1px 10px darkolivegreen;
        }
        #intro p {
            font-size: 1.5rem;
            color: white;
        }
        .btn-group {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            gap: 30px;
        }
        .btn {
            background: darkolivegreen;
            color: white;
            border: 2px solid white;
            padding: 15px 50px;
            border-radius: 40px;
            transition: background-color 200ms ease-in-out, transform 300ms ease-in-out;

        }
        .btn:hover {
            background-color: orangered;
            transform: translateY(5px);
        }
        #features {
            padding: 50px 100px;
            display: flex;
            flex-direction: column;
            gap: 70px;
        }
        .section-header {
            font-size: 4rem;
            color: darkolivegreen;
            font-weight: 700;
            position: relative;
        }
        .section-header::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: -10px;
            display: block;
            width: 100px;
            border-bottom: 4px solid darkolivegreen;
        }

        .grid {
            display: flex;
            gap: 20px;
        }
        .box {
            border: 1px solid rgba(211, 211, 211, .3);
            box-shadow: 1px 2px 10px -5px lightblue;
            position: relative;
            padding: 20px 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-start;
            width: 33.33%;
            gap: 15px;
            transition: background-color 500ms ease-in-out;
            border-radius: 15px;
        }
        .box::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            left: 0;
            right: 0;
            box-shadow: -1px -2px 10px -5px lightblue;
        }
        .box:hover {
            background-color: darkolivegreen;
        }
        .box:hover * {
            color: #fff;
        }
        .box i {
            font-size: 3rem;
            border: 2px solid darkolivegreen;
            color: darkolivegreen;
            padding: 20px;
            border-radius: 8px;
            transform: rotate(-15deg);
            transition: transform 400ms ease;
        }
        .box:hover i {
            border-color: #fff;
            background-color: #fff;
            color: darkolivegreen;
            transform: rotate(0);
        }
        .box h3 {
            font-weight: 400;
            font-size: 1rem;
            color: darkolivegreen;
            text-transform: uppercase;
        }
        .contact {
            padding: 50px 100px;
            display: flex;
            flex-direction: column;
            gap: 70px;
        }
        form {
            width: 60%;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 10px;

        }
        .form-control {
            display: block;
            border: 1px solid darkolivegreen;
            width: 100%;
            padding: 3px 10px;
            border-radius: 3px;
        }
        form .btn {
            background-color: darkolivegreen;
            color: #fff;
            padding: 10px 30px;

        }
        form .btn:hover {
            cursor: pointer;
        }
        .mini-info div {
            margin-bottom: 20px;
        }
        .contact h4 {
            font-weight: 600;
        }
        footer {
            margin-top: 70px;
            min-height: 100px;
            padding: 20px 50px;
            border-top: 1px solid darkolivegreen;
            display: flex;
            justify-content: space-between;
        }
        footer b {
            font-weight: 600;
        }
        /* Mobile Styles */
        @media (width <= 692px) {
            #intro {
                padding: 50px 0;
            }
            #intro > section {
                width: 85%;
            }
            #intro h1 {
                font-size: 2rem;
                line-height: 1em;
                margin-bottom: 20px;
            }
            .btn-group {
                flex-direction: column;
            }
            #features {
                padding: 50px 20px;

            }
            .grid {
                flex-direction: column;
            }
            .box {
                width: 100%;
            }
            .section-header {
                font-size: 2rem;
            }
            .contact {
                padding: 50px 20px;
            }
            .contact form {
                width: 100%;
            }
        }
    /*    Tablet Styles */
        @media (width > 692px) and (width <= 1000px) {
            #intro {
                min-height: 60vh;
            }
            #features, .contact {
                padding: 50px;
            }
            #features .grid {
                flex-wrap: wrap;
            }
            .box {
                width: 48%;
            }
            .contact .grid {
                flex-direction: column;
            }
            form {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<main>
    <div id="intro">
        <section>
            <h1>Examination Attendance Management System for Faculty of Communication and Information Sciences</h1>
            <p>Introducing my attendance Management system written with PHP with MySQL Data Storage Facility. This is a simple attendance management system designed for computer science students as a beginner-to-intermediate level project. The system allows tracking student attendance for classes/courses.</p>
            <section class="btn-group">
                <a href="./admin/" class="btn">Admin Login</a>
                <a href="./student/" class="btn">Student Login</a>
            </section>
        </section>
    </div>
    <div id="features">
        <h1 class="section-header">Features</h1>
        <section class="grid">
            <div class="box">
                <i class="fa fa-users-cog"></i>
                <h3>User Management</h3>
                <ul>
                    <li>Admin login</li>
                    <li>Student login</li>
                </ul>
            </div>
            <div class="box">
                <i class="fas fa-calendar-check"></i>
                <h3>Attendance Tracking</h3>
                <ul>
                    <li>Attendance Tracking</li>
                    <li>Mark attendance by course/class</li>
                    <li>Daily attendance records</li>
                    <li>View attendance reports</li>
                </ul>
            </div>
            <div class="box">
                <i class="fa fa-universal-access"></i>
                <h3>Basic Functionalities</h3>
                <ul>
                    <li>Add/remove students</li>
                    <li>Create/modify courses</li>
                    <li>Generate attendance reports</li>
                    <li>and lots More</li>
                </ul>
            </div>
        </section>
    </div>
    <div class="contact">
        <h2 class="section-header">Contact Us</h2>
        <div class="grid">
            <form action="">
                <div class="form-group">
                    <label for="fullname">Fullname</label>
                    <input type="text" name="fullname" required placeholder="Enter your fullname" id="fullname" class="form-control">
                </div>
                <div class="form-group">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" required placeholder="Enter your E-mail address" class="form-control">
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" name="phone" required placeholder="Enter your Phone No" class="form-control" id="phone">
                </div>
                <div class="form-group">
                    <label for="msg">Message</label>
                    <textarea name="message" id="msg" cols="30" rows="5" class="form-control"></textarea>
                </div>
                <button type="submit" class="btn">Send Message</button>
            </form>
            <section class="mini-info">
                <p>Please feel free to get in touch Today</p>

                <h3>Contact Details</h3>
                <div>
                    <h4>E-mail</h4>
                    <p><a href="mailto: hello@codedom.world">hello@codedom.world</a></p>
                </div>
                <div>
                    <h4>Phone Numbers</h4>
                    <p><a href="tel: 08068799451">08068799451</a></p>
                    <p><a href="tel: 09036830873">09036830873</a></p>
                </div>
            </section>
        </div>
    </div>
</main>
<footer>
    <p>Copyright &copy; 2025</p>
    <p><b>Powered by <b>Fareed</b></b></p>
</footer>
</body>
</html>