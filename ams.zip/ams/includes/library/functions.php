<?php
function redirectTo(string $location): bool
{
    $file = str_contains($location, '.php') ? $location : "{$location}.php";
    if(!empty($file) && is_file($file)) {
        header('Location: '. $file);
    }
    return false;
}

function setDefault(array $fields, string $method='post'): void
{
    $method = strtolower($method);
    foreach ($fields as $field) {
        switch ($method) {
            case 'post':
                if(!isset($_POST[$field])) {
                    $_POST[$field] = '';
                }
                break;
            case 'get':
                if(!isset($_GET[$field])) {
                    $_GET[$field] = '';
                }
                break;
        }
    }
}
function show_error(array $errors, string $field): string
{
    if(!empty($errors) && array_key_exists($field, $errors)) {
        return array_shift($errors[$field]);
    }
    return '';
}
function validate_staff_logged_in(): bool
{
    return isset($_SESSION['admin']['sid']);
}
function validate_student_logged_in(): bool
{
    return isset($_SESSION['student']['sid']);
}
function clean_string(string $string): string
{
    return strtolower(trim(htmlspecialchars($string, ENT_QUOTES)));
}
function validateInput(array $fields, string $type='get', $table="students"): array
{
    $errors = array();
    $type = strtolower($type);
    $method = ($type === 'get') ? $_GET :  ($type === 'post' ? $_POST : null);
    if(empty($method)) {
        die(new Exception("Missing required parameter '{$type}'", 400));
    }
    foreach($fields as $field => $field_rules) {
        $value = gettype($method[$field]) === 'string' ? trim($method[$field]) : $method[$field];
        foreach($field_rules as $rule => $rule_value) {
            if($rule === 'required' && empty($value)) {
                $errors[$field][] = "{$field_rules['display']} is required";
            } else if(!empty($value)) {
                switch($rule) {
                    case 'min':
                            if(strlen($value) < $rule_value) {
                                $errors[$field][] = "{$field_rules['display']} must be {$rule_value} characters or more";
                            }
                        break;
                    case 'max':
                            if(strlen($value) > $rule_value) {
                                $errors[$field][] = "{$field_rules['display']} must not be more than {$rule_value} characters";
                            }
                        break;
                    case 'unique':
                        $found = get_table_record_by_col($table, [$field => $value]);
                        if(!empty($found)) {
                            $errors[$field][] = "{$field_rules['display']} already exists";
                        }
                        break;
                    case 'match':
                        if($value !== $method[$rule_value]) {
                            $errors[$field][] = "{$field_rules['display']} does not match {$rule_value}";
                        }
                        break;
                }
            }
        }
    }
    return $errors;
}

function add_to_db_table(string $table_name, array $data): bool {
    try {
        global $db;
        $sql = "INSERT INTO `{$table_name}` (";
        $keys = array_keys($data);
        $track = 1;
        $partials = '';
        foreach($keys as $key) {
            if($track < count($keys)) {
                $partials .= "`{$key}`, ";
            } else {
                $partials .= "`{$key}`) VALUES (";
            }
            $track++;
        }
        $sql .= $partials;
        $partials = '';
        $track = 1;
        foreach($keys as $key) {
            if($track < count($keys)) {
                $partials .= " :{$key}, ";
            } else {
                $partials .= " :{$key} )";
            }
            $track++;
        }
        $sql .= $partials;
       $values = array_values($data);
       $stmt = $db->prepare($sql);
        for($i = 0; $i < count($values); $i++) {
            $stmt->bindParam(":{$keys[$i]}", $values[$i]);
        }
        return $stmt->execute();
    }catch (PDOException $e) {
        var_dump($e->getMessage());
    }
    return false;
}

function get_table_records(string $table_name, array $data=array()): array | object | null
{
    global $db;
    if(empty($data)) {
        $sql = "SELECT * FROM `{$table_name}`";
    } else {
        $partials = '';
        $track = 1;
        foreach($data as $key) {
            if($track < count($data)) {
                $partials .= "`{$key}`, ";
                } else {
                    $partials .= "`{$key}` ";
                }
                $track++;
        }

        $sql = "SELECT {$partials} FROM `{$table_name}`";

    }
    $stmt = $db->prepare($sql);
    $stmt->execute();
  return $stmt->rowCount() > 1 ? $stmt->fetchAll(PDO::FETCH_OBJ) : ($stmt->rowCount() === 1 ? $stmt->fetch(PDO::FETCH_OBJ) : null);
}
function get_table_records_count(string $table_name, array $criteria=array()): int | null
{
    global $db;
    if(!empty($criteria)) {
        $sql = "SELECT * FROM `{$table_name}` WHERE ";
       $keys = array_keys($criteria);
       $values = array_values($criteria);
       $track = 1;
       $partials = '';
       foreach($keys as $key) {
           if($track < count($keys)) {
               $partials .= "`{$key}` =  :{$key} AND ";
           } else {
               $partials .= " `{$key}` = :{$key}";
           }
           $track++;
       }
       $sql .= $partials;
        $stmt = $db->prepare($sql);
       for($i = 0; $i < count($values); $i++) {
           $stmt->bindParam(":{$keys[$i]}", $values[$i]);
       }
    } else {
        $sql = "SELECT * FROM `{$table_name}`";
        $stmt = $db->prepare($sql);
    }
    $stmt->execute();
    return $stmt->rowCount();
}
function update_db_table(string $table_name, array $data, array $criteria): bool | string
{
     global $db;
     $sql = "UPDATE `{$table_name}` SET ";
     $keys = array_keys($data);
     $values = array_values($data);
     $track = 1;
     $partials = '';
     foreach($keys as $key) {
         if($track < count($keys)) {
             $partials .= "`{$key}` = :{$key}, ";
         } else {
             $partials .= " `{$key}` = :{$key}";
         }
         $track++;
     }
     $sql .= $partials . ' WHERE ';
     $track = 1;
     $partials = '';
     foreach($criteria_keys = array_keys($criteria) as $mkey) {
         if($track < count($criteria)) {
             $partials .= "`{$mkey}` = :{$mkey} AND ";
         } else {
             $partials .= " `{$mkey}` = :{$mkey}";
         }
    }
     $sql .= $partials;
     $stmt = $db->prepare($sql);
    $criteria_values = array_values($criteria);
//     let bind the updated Values
    for($i = 0; $i < count($values); $i++) {
        $stmt->bindParam(":{$keys[$i]}", $values[$i]);
    }
//    let bind the Criteria Values
    for($i = 0; $i < count($criteria_values); $i++) {
        $stmt->bindParam(":{$criteria_keys[$i]}", $criteria_values[$i]);
    }
     return $stmt->execute();
}
function delete_table_record($table_name, array $criteria=array()): bool
{
    global $db;
    $keys = array_keys($criteria);
    $values = array_values($criteria);
    $track = 1;
    $partials = '';
    $sql = "DELETE FROM `{$table_name}` WHERE ";
    foreach($keys as $key) {
        if($track < count($keys)) {
            $partials .= "`{$key}` =  :{$key} AND ";
        } else {
            $partials .= " `{$key}` = :{$key}";
        }
    }
    $sql .= $partials;
    $stmt = $db->prepare($sql);
    for($i = 0; $i < count($values); $i++) {
        $stmt->bindParam(":{$keys[$i]}", $values[$i]);
    }
    if($stmt->execute()) {
        return true;
    }
    return false;
}
function authenticate_staff(string $email, string $password): object | bool
{
    $found_user = get_table_record_by_col('staffs', [ 'email' => $email ]);
    if($found_user) {
        if(password_verify($password, $found_user->password)) {
            return $found_user;
        }
        return false;
    } else {
        return false;
    }
}
function authenticate_student(string $matric_no, string $password): object | bool
{
    $found_user = get_table_record_by_col('students', [ 'matric_no' => $matric_no ]);
    if($found_user) {
        if(password_verify($password, $found_user->password)) {
            return $found_user;
        }
        return false;
    } else {
        return false;
    }
}

function get_table_record_by_col(string $table_name, array $criteria=array()): array | object | null
{
    global $db;
    $sql = "SELECT * FROM `{$table_name}`";
    $keys = array_keys($criteria);
    if (!empty($criteria)) {
        $partials = '';
        $track = 1;
        $sql .= " WHERE ";
        foreach($keys as $key) {
            if($track < count($keys)) {
                $partials .= "`{$key}` =  :{$key} AND ";
            } else {
                $partials .= "`{$key}` = :{$key}";
            }
            $track++;
        }
        $sql .= $partials;
    }

    $stmt = $db->prepare($sql);
    if(!empty($criteria)) {
        $values = array_values($criteria);
        for($i = 0; $i < count($values); $i++) {
            $stmt->bindParam(":{$keys[$i]}", $values[$i]);
        }
    }
    $stmt->execute();
    if($stmt->rowCount() > 1) {
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    } elseif ($stmt->rowCount() === 1) {
        return $stmt->fetch(PDO::FETCH_OBJ);
    }
    return null;

}
function is_ajax_request(): bool
{
    return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
}

function createFolder($dir_name): bool
{
    if(!is_dir($dir_name)) {
        mkdir($dir_name, 0777, true);
        return true;
    }
    return false;
}
function file_delete($filePath): bool
{
    if(file_exists($filePath)) {
        unlink($filePath);
        return true;
    }
    return false;
}
function validate_image_file($original_name): string | bool {
    $allowed_extensions = array("png", "jpg", "jpeg");
    $filename_array = explode(".", $original_name);
    if(in_array(end($filename_array), $allowed_extensions)) {
        $file_extension = array_pop($filename_array);
        $new_name = 'IMG_' . date('Y') . "_" . date('m') . '_' . date('d') . '_' . time() . '.' . $file_extension;
        return $new_name;
    }
    return false;
}
function get_unique_level_dept(int $dept): array
{
    global $db;
    $sql = "SELECT DISTINCT `level` FROM `courses` WHERE `department` = :dept";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(":dept", $dept, PDO::PARAM_INT);
    if($stmt->execute() && $stmt->rowCount()) {
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    } else {
        return [];
    }
}
function get_course_level($student_id): int | bool
{
    $course_registrations = get_table_record_by_col('course_registrations', [ 'student_id' => $student_id ]);
    if($course_registrations === null) {
        return 100;
    } elseif(is_object($course_registrations)) {
       return ($course_registrations->level + 100);
    } elseif(is_array($course_registrations) && count($course_registrations) >= 1) {
        $last_record = array_pop($course_registrations);
        return $last_record->level + 100;
    }
    return false;
}
function format_date($date, $format="Y-m-d"): string
{
    try {
        $date = new DateTime($date);
        return $date->format($format);
    } catch (Exception $e) {
        return false;
    }
}
function getFullname(int $id) {
    $student = get_table_record_by_col('students', [ 'id' => $id ]);
    if(!empty($student)) {
        return trim($student->surname . ' ' . $student->firstname . ' ' . $student->othername);
    } else {
        return false;
    }
}

function  old($value, $type='post'): string | null | int | bool | array
{
    $type = strtolower($type);
    switch ($type) {
        case 'post':
            if(isset($_POST[$value])) {
                return $_POST[$value];
            }
            break;
       case 'get':
          if(isset($_GET[$value])) {
              return $_GET[$value];
          }
    }
    return '';
}
function set_flash_message(string $type, string $name, string $message): void
{
    $_SESSION['flash_message'] = [
        'type' => $type,
        'message' => $message
    ];
}
function get_flash_message(string $name): string
{
    $content = '';
    if(isset($_SESSION['flash_message'])) {
        $content = $_SESSION['flash_message']['message'];
        unset($_SESSION['flash_message']);
    }
    return $content;
}