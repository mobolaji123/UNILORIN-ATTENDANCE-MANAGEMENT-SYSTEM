<?php
defined('DSN') ? '' : define('DSN', 'mysql:host=localhost;dbname=ams');
defined('DB_NAME') ? '' : define('DB_NAME', 'ams');
defined('DB_USER') ? '' : define('DB_USER', 'root');
defined('DB_PASS') ? '' : define('DB_PASS', '');
try {
    $db = new PDO(DSN, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//    echo('DB Connected Successfully');
} catch(PDOException $e) {
    die("Failed: " . $e->getMessage());
}