<?php
require_once '../includes/db-config.php';
require_once '../includes/library/functions.php';

if(!is_ajax_request()) {
    die(http_response_code(403));
} else {
    if(!empty($_GET)) {
        $sid = $_GET['sid'];
        $action = $_GET['action'];
        $student = get_table_record_by_col('students', ['id' => $sid]);
        switch($action) {
            case 'restrict':
                update_db_table('students', ['status' => 'restrict'], ['id' => $sid]);
                $action = 'unrestrict';
                break;
            case 'unrestrict':
                update_db_table('students', ['status' => null], ['id' => $sid]);
                $action = 'restrict';
                break;
        }
        echo json_encode(['action' => $action]);
    }
}

