<?php
require_once '../includes/db-config.php';
require_once '../includes/library/functions.php';

if(!is_ajax_request()) {
    die(http_response_code(403));
} else {
    if(!empty($_GET)) {
        $id = $_GET['id'];
        $status = $_GET['status'];
       update_db_table('attendance_settings', ['status' => $status], ['id' => $id]);
        echo json_encode(['status' => 'done']);
    }
}

