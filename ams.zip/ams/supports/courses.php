<?php
require_once '../includes/db-config.php';
require_once '../includes/library/functions.php';

if(!is_ajax_request()) {
   die(http_response_code(403));
}
if(!empty($_GET)) {
    $level = (int)$_GET['level'];
    $dpt = (int)$_GET['dpt'];
    if(!empty($level) && !empty($dpt)) {
        $courses = get_table_record_by_col('courses', [
            'level' => $level,
            'department' => $dpt
        ]);
        echo(json_encode($courses));
    }
}
